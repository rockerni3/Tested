package com.example.model

enum class ModelDownloadStatus {
    NOT_DOWNLOADED,
    DOWNLOADING,
    VERIFYING,
    DOWNLOADED,
    INITIALIZING,
    READY,
    GENERATING,
    UNLOADING,
    FAILED,
    ERROR
}

data class ModelInfo(
    val id: String = "gemma-4-e2b-it",
    val name: String = "Gemma 4 E2B Instruct (LiteRT-LM)",
    val variant: String = "Mobile Quantized INT4 (Snapdragon 8s Gen 3)",
    val parameters: String = "2.6B Parameters",
    val requiredSizeBytes: Long = 1_850_000_000L, // ~1.85 GB
    val requiredStorageMb: Int = 1850,
    val memoryFootprintMb: Int = 1450,
    val sourceUrl: String = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm",
    val description: String = "Official LiteRT-LM model from litert-community (https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm). Instant ~120ms inference and low memory overhead on Poco F6 (Snapdragon 8s Gen 3).",
    val supportedBackends: List<String> = listOf("Qualcomm Hexagon NPU", "Adreno 735 GPU", "ARM NEON CPU"),
    val capabilities: List<String> = listOf("Claude Code ReAct Loop", "Autonomous Screen Reasoning", "Ad & Consent Dismissal", "First Organic Link Selection", "Compound Intent Decomposition", "Episodic Fast-Path Memory")
)

val AVAILABLE_MODELS = listOf(
    ModelInfo(
        id = "gemma-4-e2b-it",
        name = "Gemma 4 E2B Instruct (LiteRT-LM)",
        variant = "Mobile Quantized INT4 (Snapdragon 8s Gen 3)",
        parameters = "2.6B Parameters",
        requiredSizeBytes = 1_850_000_000L,
        requiredStorageMb = 1850,
        memoryFootprintMb = 1450,
        sourceUrl = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm",
        description = "Official LiteRT-LM model from litert-community (https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm). Instant ~120ms inference and low memory overhead on Poco F6 (Snapdragon 8s Gen 3).",
        supportedBackends = listOf("Qualcomm Hexagon NPU", "Adreno 735 GPU", "ARM NEON CPU"),
        capabilities = listOf("Claude Code ReAct Loop", "Autonomous Screen Reasoning", "Ad & Consent Dismissal", "First Organic Link Selection", "Compound Intent Decomposition", "Episodic Fast-Path Memory")
    ),
    ModelInfo(
        id = "gemma-4-e4b-it",
        name = "Gemma 4 E4B Instruct (LiteRT-LM)",
        variant = "High-Capacity Mobile INT4 (Snapdragon 8s Gen 3)",
        parameters = "4.2B Parameters",
        requiredSizeBytes = 2_950_000_000L,
        requiredStorageMb = 2950,
        memoryFootprintMb = 2200,
        sourceUrl = "https://huggingface.co/litert-community/gemma-4-E4B-it-litert-lm/resolve/main/gemma-4-E4B-it.litertlm",
        description = "Official LiteRT-LM model from litert-community (https://huggingface.co/litert-community/gemma-4-E4B-it-litert-lm). Higher reasoning capacity for multi-step browser navigation and complex accessibility hierarchies.",
        supportedBackends = listOf("Snapdragon Adreno 735 GPU", "Qualcomm Hexagon NPU", "ARM NEON CPU"),
        capabilities = listOf("Claude Code ReAct Loop", "Deep Screen Understanding", "Multi-Turn Workflow Planning", "Interstitial Modal Auto-Bypass", "Episodic Fast-Path Memory")
    ),
    ModelInfo(
        id = "gemma-2-2b-it",
        name = "Gemma 2 2B Instruct (LiteRT / MediaPipe)",
        variant = "Mobile Quantized INT4 (Official Google)",
        parameters = "2.6B Parameters",
        requiredSizeBytes = 1_850_000_000L,
        requiredStorageMb = 1850,
        memoryFootprintMb = 1500,
        sourceUrl = "https://huggingface.co/litert-community/Gemma2-2B-IT/resolve/main/gemma2-2b-it-gpu-int4.bin",
        description = "Google's official Gemma 2 2B on-device model for MediaPipe GenAI / LiteRT on Qualcomm Snapdragon 8s Gen 3 (Poco F6). Native INT4 GPU acceleration.",
        supportedBackends = listOf("Snapdragon Adreno 735 GPU", "Qualcomm Hexagon NPU", "CPU NEON"),
        capabilities = listOf("Claude Code ReAct Loop", "Ad & Modal Auto-Bypass", "Account Consent Resolver", "First Organic Link Selection", "Compound Intent Decomposition", "Episodic Fast-Path Memory")
    ),
    ModelInfo(
        id = "gemma-2-9b-it",
        name = "Gemma 2 9B Instruct (High-Capacity)",
        variant = "Mobile Quantized INT4 (Official Google)",
        parameters = "9.2B Parameters",
        requiredSizeBytes = 5_400_000_000L,
        requiredStorageMb = 5400,
        memoryFootprintMb = 4200,
        sourceUrl = "https://huggingface.co/google/gemma-2-9b-it",
        description = "Google's 9.2B flagship on-device model. Deep screen hierarchy comprehension and autonomous multi-step web planning for Snapdragon 8s Gen 3.",
        supportedBackends = listOf("Snapdragon Adreno 735 GPU", "ARM NEON CPU"),
        capabilities = listOf("Deep Hierarchy Comprehension", "Multi-Turn ReAct Loop", "Autonomous Browser Navigation", "Complex Task Decomposition")
    ),
    ModelInfo(
        id = "smollm-135m-fast",
        name = "SmolLM 135M Instruct (Fast On-Device 94MB)",
        variant = "Mobile Quantized Q4_K_M (Open / Un-gated)",
        parameters = "135M Parameters",
        requiredSizeBytes = 94_000_000L,
        requiredStorageMb = 94,
        memoryFootprintMb = 180,
        sourceUrl = "https://huggingface.co/QuantFactory/SmolLM-135M-Instruct-GGUF/resolve/main/SmolLM-135M-Instruct.Q4_K_M.gguf",
        description = "Ultra-fast open lightweight model for instant testing. Ungated and downloads in seconds without requiring HuggingFace authentication.",
        supportedBackends = listOf("Qualcomm Snapdragon CPU / NPU", "ARM NEON"),
        capabilities = listOf("Rapid Intent Parsing", "Tool Dispatch", "Local Offline Benchmarks")
    ),
    ModelInfo(
        id = "qwen-2.5-7b-mobile",
        name = "Qwen 2.5 7B Mobile-Coder Agent",
        variant = "Autonomous Tool-Use (INT4)",
        parameters = "7.6B Parameters",
        requiredSizeBytes = 4_100_000_000L,
        requiredStorageMb = 4100,
        memoryFootprintMb = 2950,
        sourceUrl = "https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-GGUF/resolve/main/qwen2.5-7b-instruct-q4_k_m.gguf",
        description = "Programmatic tool-calling specialist. Decomposes compound instructions into sequential tool invocations and self-learning action replay.",
        supportedBackends = listOf("Snapdragon Hexagon NPU", "CPU NEON"),
        capabilities = listOf("Multi-turn Reasoning", "Compound Action Decomposition", "Episodic Experience Caching", "Self-Correction")
    )
)

data class ModelDownloadState(
    val status: ModelDownloadStatus = ModelDownloadStatus.NOT_DOWNLOADED,
    val selectedModelId: String = "gemma-4-e2b-it",
    val bytesDownloaded: Long = 0L,
    val totalBytes: Long = 1_850_000_000L,
    val downloadSpeedBytesPerSec: Long = 0L,
    val progressPercent: Float = 0.0f,
    val isPaused: Boolean = false,
    val errorMessage: String? = null,
    val selectedBackend: String = "Snapdragon Hexagon NPU + GPU",
    val isModelLoadedInMemory: Boolean = false,
    val freeDeviceStorageBytes: Long = 45_000_000_000L,
    val onDiskFilePath: String? = null,
    val actualFileSizeBytes: Long = 0L,
    val customModelPath: String = "",
    val sha256Checksum: String? = null,
    val isIntegrityVerified: Boolean = false,
    val diagnosticInfo: String? = null
)
