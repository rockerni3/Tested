package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "agent_tasks")
data class AgentTaskEntity(
    @PrimaryKey
    val id: String,
    val goal: String,
    val rawVoicePrompt: String,
    val startTime: Long,
    val endTime: Long?,
    val status: String,
    val stepsCount: Int,
    val executedPackage: String?,
    val finalSummary: String?
)

@Entity(tableName = "agent_steps")
data class AgentStepEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val taskId: String,
    val stepIndex: Int,
    val actionType: String,
    val target: String,
    val parametersJson: String,
    val thought: String,
    val observationBefore: String,
    val observationAfter: String,
    val verificationStatus: String,
    val isCompleted: Boolean,
    val durationMs: Long
)

@Entity(tableName = "task_experiences")
data class TaskExperienceEntity(
    @PrimaryKey
    val id: String,
    val intentPattern: String,
    val canonicalPrompt: String,
    val targetPackage: String,
    val executionCount: Int,
    val lastSuccessTimestamp: Long,
    val averageDurationMs: Long,
    val learnedBypassRules: String,
    val learnedSelectors: String,
    val fastPathStepsCount: Int
)
