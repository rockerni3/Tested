package com.example.model

enum class AgentActionType {
    LAUNCH_APPLICATION,
    INSPECT_SCREEN,
    FIND_UI_ELEMENT,
    CLICK_ELEMENT,
    ENTER_TEXT,
    CLEAR_TEXT,
    SCROLL_SCREEN,
    PRESS_KEY,
    WAIT_FOR_ELEMENT,
    VERIFY_CONDITION,
    REQUEST_CONFIRMATION,
    SPEAK_FEEDBACK,
    TASK_COMPLETE
}

enum class VerificationStatus {
    PENDING,
    SUCCESS,
    FAILED,
    RECOVERED,
    ACTION_REJECTED,
    TARGET_NOT_FOUND,
    STALE_OBSERVATION,
    PERMISSION_REQUIRED,
    SCREEN_UNAVAILABLE,
    CONFIRMATION_REQUIRED
}

enum class TaskStatus {
    IDLE,
    WAKE_WORD_DETECTED,
    LISTENING,
    REASONING,
    AWAITING_CONFIRMATION,
    EXECUTING,
    VERIFYING,
    COMPLETED,
    FAILED,
    INTERRUPTED,
    CANCELLED
}

data class AgentStep(
    val stepIndex: Int,
    val actionType: AgentActionType,
    val target: String,
    val parameters: Map<String, String> = emptyMap(),
    val thought: String = "",
    val observationBefore: String = "",
    val observationAfter: String = "",
    val verificationStatus: VerificationStatus = VerificationStatus.PENDING,
    val isCompleted: Boolean = false,
    val durationMs: Long = 0L,
    val errorMessage: String? = null
)

data class AgentTask(
    val id: String,
    val goal: String,
    val rawVoicePrompt: String,
    val startTime: Long = System.currentTimeMillis(),
    val endTime: Long? = null,
    val status: TaskStatus = TaskStatus.IDLE,
    val steps: List<AgentStep> = emptyList(),
    val currentStepIndex: Int = 0,
    val finalSummary: String? = null,
    val executedPackage: String? = null
) {
    val durationSeconds: Float
        get() = ((endTime ?: System.currentTimeMillis()) - startTime) / 1000f
}
