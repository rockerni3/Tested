package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class RockerAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "RockerAccessibilityService connected")
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_CLICKED or
                    AccessibilityEvent.TYPE_VIEW_SCROLLED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            notificationTimeout = 100
        }
        serviceInfo = info
        AccessibilityBridge.onServiceConnected(this)
        captureCurrentWindow()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                captureCurrentWindow()
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "RockerAccessibilityService interrupted")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        AccessibilityBridge.onServiceDisconnected()
        return super.onUnbind(intent)
    }

    fun captureCurrentWindow() {
        try {
            val root = rootInActiveWindow ?: try {
                windows.firstOrNull { it.isFocused || it.isActive }?.root
            } catch (_: Exception) {
                null
            }
            AccessibilityBridge.updateScreenHierarchy(root)
        } catch (e: Exception) {
            Log.e(TAG, "Error capturing active window: ${e.message}")
        }
    }

    fun dispatchClickGesture(x: Float, y: Float, onComplete: (Boolean) -> Unit = {}) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            val path = android.graphics.Path().apply {
                moveTo(x.coerceAtLeast(1f), y.coerceAtLeast(1f))
            }
            val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 60)
            val gesture = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(stroke)
                .build()
            dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: android.accessibilityservice.GestureDescription?) {
                    Log.d(TAG, "Physical touch tap executed at ($x, $y)")
                    captureCurrentWindow()
                    onComplete(true)
                }
                override fun onCancelled(gestureDescription: android.accessibilityservice.GestureDescription?) {
                    Log.w(TAG, "Touch tap gesture cancelled at ($x, $y)")
                    onComplete(false)
                }
            }, null)
        } else {
            onComplete(false)
        }
    }

    fun dispatchScrollGesture(startX: Float, startY: Float, endX: Float, endY: Float, onComplete: (Boolean) -> Unit = {}) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            val path = android.graphics.Path().apply {
                moveTo(startX, startY)
                lineTo(endX, endY)
            }
            val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 250)
            val gesture = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(stroke)
                .build()
            dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: android.accessibilityservice.GestureDescription?) {
                    captureCurrentWindow()
                    onComplete(true)
                }
                override fun onCancelled(gestureDescription: android.accessibilityservice.GestureDescription?) {
                    onComplete(false)
                }
            }, null)
        } else {
            onComplete(false)
        }
    }

    companion object {
        private const val TAG = "RockerA11yService"
    }
}
