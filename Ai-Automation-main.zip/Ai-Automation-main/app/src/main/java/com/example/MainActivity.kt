package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ai.WakeState
import com.example.ui.RockerTab
import com.example.ui.RockerViewModel
import com.example.ui.screens.AgentHomeScreen
import com.example.ui.screens.HistoryLogsScreen
import com.example.ui.screens.ModelManagerScreen
import com.example.ui.screens.ScreenInspectorScreen
import com.example.ui.screens.SettingsGuideScreen
import com.example.ui.theme.RockerBackground
import com.example.ui.theme.RockerBorder
import com.example.ui.theme.RockerCyanPrimary
import com.example.ui.theme.RockerGreenSuccess
import com.example.ui.theme.RockerSurface
import com.example.ui.theme.RockerTextMuted
import com.example.ui.theme.RockerTextPrimary
import com.example.ui.theme.RockerTextSecondary
import com.example.ui.theme.RockerTheme

class MainActivity : ComponentActivity() {

    private val viewModel: RockerViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val context = LocalContext.current
            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { isGranted ->
                if (isGranted) {
                    viewModel.wakeWordEngine.startListening(true)
                }
            }

            LaunchedEffect(Unit) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }

            RockerTheme {
                val selectedTab by viewModel.selectedTab.collectAsState()
                val wakeState by viewModel.wakeState.collectAsState()
                val audioEnergy by viewModel.audioEnergy.collectAsState()
                val isExecuting by viewModel.isExecuting.collectAsState()
                val liveTranscript by viewModel.liveTranscript.collectAsState()
                val currentTask by viewModel.currentTask.collectAsState()
                val memoryStats by viewModel.memoryStats.collectAsState()
                val isAccessibilityConnected by viewModel.isAccessibilityConnected.collectAsState()
                val currentSnapshot by viewModel.currentScreenSnapshot.collectAsState()
                val modelState by viewModel.modelDownloadState.collectAsState()
                val historyTasks by viewModel.historyTasks.collectAsState()
                val learnedExperiences by viewModel.learnedExperiences.collectAsState()
                val settings by viewModel.settings.collectAsState()
                val diagnosticResult by viewModel.diagnosticResult.collectAsState()
                val isDiagnosticRunning by viewModel.isDiagnosticRunning.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = RockerBackground,
                    topBar = {
                        CenterAlignedTopAppBar(
                            title = {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(if (isExecuting) RockerGreenSuccess else RockerCyanPrimary)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "ROCKER AI",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 18.sp,
                                            color = RockerTextPrimary,
                                            letterSpacing = 2.sp
                                        )
                                    }
                                    Text(
                                        text = "FULLY OFFLINE AUTONOMOUS AGENT",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = RockerTextMuted,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            },
                            actions = {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = RockerSurface,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder),
                                    modifier = Modifier.padding(end = 12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(if (isAccessibilityConnected) RockerGreenSuccess else Color(0xFFFFB300))
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isAccessibilityConnected) "A11Y ON" else "SANDBOX",
                                            color = if (isAccessibilityConnected) RockerGreenSuccess else Color(0xFFFFB300),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = RockerBackground
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = RockerSurface,
                            modifier = Modifier
                                .navigationBarsPadding()
                                .border(1.dp, RockerBorder)
                                .testTag("main_bottom_nav")
                        ) {
                            NavigationBarItem(
                                selected = selectedTab == RockerTab.AGENT,
                                onClick = { viewModel.setTab(RockerTab.AGENT) },
                                icon = { Icon(Icons.Default.SmartToy, contentDescription = "Agent") },
                                label = { Text("Agent", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = RockerCyanPrimary,
                                    selectedTextColor = RockerCyanPrimary,
                                    unselectedIconColor = RockerTextMuted,
                                    unselectedTextColor = RockerTextMuted,
                                    indicatorColor = RockerCyanPrimary.copy(alpha = 0.15f)
                                )
                            )

                            NavigationBarItem(
                                selected = selectedTab == RockerTab.INSPECTOR,
                                onClick = { viewModel.setTab(RockerTab.INSPECTOR) },
                                icon = { Icon(Icons.Default.Visibility, contentDescription = "Inspector") },
                                label = { Text("Inspector", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = RockerCyanPrimary,
                                    selectedTextColor = RockerCyanPrimary,
                                    unselectedIconColor = RockerTextMuted,
                                    unselectedTextColor = RockerTextMuted,
                                    indicatorColor = RockerCyanPrimary.copy(alpha = 0.15f)
                                )
                            )

                            NavigationBarItem(
                                selected = selectedTab == RockerTab.MODEL_RAM,
                                onClick = {
                                    viewModel.refreshMemoryStats()
                                    viewModel.setTab(RockerTab.MODEL_RAM)
                                },
                                icon = { Icon(Icons.Default.Memory, contentDescription = "Model & RAM") },
                                label = { Text("Hardware", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = RockerCyanPrimary,
                                    selectedTextColor = RockerCyanPrimary,
                                    unselectedIconColor = RockerTextMuted,
                                    unselectedTextColor = RockerTextMuted,
                                    indicatorColor = RockerCyanPrimary.copy(alpha = 0.15f)
                                )
                            )

                            NavigationBarItem(
                                selected = selectedTab == RockerTab.LOGS,
                                onClick = { viewModel.setTab(RockerTab.LOGS) },
                                icon = { Icon(Icons.Default.History, contentDescription = "Audit Logs") },
                                label = { Text("Logs", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = RockerCyanPrimary,
                                    selectedTextColor = RockerCyanPrimary,
                                    unselectedIconColor = RockerTextMuted,
                                    unselectedTextColor = RockerTextMuted,
                                    indicatorColor = RockerCyanPrimary.copy(alpha = 0.15f)
                                )
                            )

                            NavigationBarItem(
                                selected = selectedTab == RockerTab.SETTINGS,
                                onClick = { viewModel.setTab(RockerTab.SETTINGS) },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Setup", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = RockerCyanPrimary,
                                    selectedTextColor = RockerCyanPrimary,
                                    unselectedIconColor = RockerTextMuted,
                                    unselectedTextColor = RockerTextMuted,
                                    indicatorColor = RockerCyanPrimary.copy(alpha = 0.15f)
                                )
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (selectedTab) {
                            RockerTab.AGENT -> {
                                AgentHomeScreen(
                                    wakeState = wakeState,
                                    audioEnergy = audioEnergy,
                                    isExecuting = isExecuting,
                                    liveTranscript = liveTranscript,
                                    currentTask = currentTask,
                                    learnedExperiences = learnedExperiences,
                                    activeModelName = viewModel.liteRtLm.modelName,
                                    isAccessibilityConnected = isAccessibilityConnected,
                                    isModelFilePresent = viewModel.liteRtLm.isModelFilePresent,
                                    onOrbClick = {
                                        if (isExecuting) {
                                            viewModel.cancelActiveExecution()
                                        } else {
                                            viewModel.startListeningManually()
                                        }
                                    },
                                    onSubmitPrompt = { prompt ->
                                        viewModel.submitAutonomousPrompt(prompt)
                                    },
                                    onCancelExecution = {
                                        viewModel.cancelActiveExecution()
                                    },
                                    onSimulateWake = {
                                        viewModel.triggerWakeWordSimulation()
                                    },
                                    onNavigateToHardware = {
                                        viewModel.setTab(RockerTab.MODEL_RAM)
                                    },
                                    onConfirmTask = {
                                        viewModel.confirmActiveTask()
                                    },
                                    onRejectTask = {
                                        viewModel.rejectActiveTask()
                                    }
                                )
                            }
                            RockerTab.INSPECTOR -> {
                                ScreenInspectorScreen(
                                    snapshot = currentSnapshot,
                                    isAccessibilityConnected = isAccessibilityConnected,
                                    onTestClickElement = { elementId ->
                                        viewModel.actionEngine.clickElement(elementId)
                                    }
                                )
                            }
                            RockerTab.MODEL_RAM -> {
                                ModelManagerScreen(
                                    modelState = modelState,
                                    modelInfo = viewModel.modelManager.modelInfo,
                                    availableModels = viewModel.modelManager.availableModels,
                                    memoryStats = memoryStats,
                                    diagnosticResult = diagnosticResult,
                                    isDiagnosticRunning = isDiagnosticRunning,
                                    onRunDiagnostic = { viewModel.runDiagnosticInference() },
                                    onSelectModel = { viewModel.selectModel(it) },
                                    onStartOrResumeDownload = { viewModel.triggerModelDownloadOrResume() },
                                    onPauseDownload = { viewModel.pauseModelDownload() },
                                    onUnloadModel = { viewModel.unloadModelFromMemory() },
                                    onLoadModel = { viewModel.loadModelIntoMemory() },
                                    onRefreshMemory = { viewModel.refreshMemoryStats() },
                                    onImportLocalModel = { viewModel.importLocalModel(it) },
                                    onSetCustomPath = { viewModel.setCustomModelPath(it) },
                                    onDownloadFromUrl = { viewModel.downloadFromCustomUrl(it) },
                                    onDeleteModel = { viewModel.deleteModel() }
                                )
                            }
                            RockerTab.LOGS -> {
                                HistoryLogsScreen(
                                    tasks = historyTasks,
                                    onClearHistory = { viewModel.clearTaskHistory() }
                                )
                            }
                            RockerTab.SETTINGS -> {
                                SettingsGuideScreen(
                                    settings = settings,
                                    isAccessibilityConnected = isAccessibilityConnected,
                                    onToggleWakeWord = { viewModel.toggleWakeWord(it) },
                                    onUpdateSensitivity = { viewModel.updateSensitivity(it) },
                                    onToggleVoiceFeedback = { viewModel.toggleVoiceFeedback(it) },
                                    onSimulateWake = { viewModel.triggerWakeWordSimulation() },
                                    onTestTts = { viewModel.testSpeechSynthesis() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
