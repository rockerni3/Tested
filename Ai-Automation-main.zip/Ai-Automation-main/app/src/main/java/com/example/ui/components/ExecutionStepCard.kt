package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AgentActionType
import com.example.model.AgentStep
import com.example.model.VerificationStatus
import com.example.ui.theme.RockerAmberWarning
import com.example.ui.theme.RockerCyanPrimary
import com.example.ui.theme.RockerGreenSuccess
import com.example.ui.theme.RockerRedError
import com.example.ui.theme.RockerSurface
import com.example.ui.theme.RockerSurfaceVariant
import com.example.ui.theme.RockerTextMuted
import com.example.ui.theme.RockerTextPrimary
import com.example.ui.theme.RockerTextSecondary
import com.example.ui.theme.RockerVioletSecondary

@Composable
fun ExecutionStepCard(
    step: AgentStep,
    modifier: Modifier = Modifier
) {
    val (actionIcon, actionColor) = getActionVisuals(step.actionType)

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = RockerSurface,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, RockerSurfaceVariant, RoundedCornerShape(12.dp))
            .testTag("step_card_${step.stepIndex}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Step # + Action Type + Verification Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(actionColor.copy(alpha = 0.15f))
                            .border(1.dp, actionColor, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${step.stepIndex}",
                            color = actionColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Icon(
                        imageVector = actionIcon,
                        contentDescription = null,
                        tint = actionColor,
                        modifier = Modifier.size(16.dp)
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = step.actionType.name.replace("_", " "),
                        color = actionColor,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }

                // Status chip
                Row(verticalAlignment = Alignment.CenterVertically) {
                    when (step.verificationStatus) {
                        VerificationStatus.SUCCESS -> {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Verified",
                                tint = RockerGreenSuccess,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "VERIFIED",
                                color = RockerGreenSuccess,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        VerificationStatus.RECOVERED -> {
                            Text(
                                text = "RECOVERED",
                                color = RockerAmberWarning,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        VerificationStatus.FAILED -> {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = "Failed",
                                tint = RockerRedError,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "FAILED",
                                color = RockerRedError,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        VerificationStatus.CONFIRMATION_REQUIRED -> {
                            Text(
                                text = "AWAITING CONFIRMATION",
                                color = RockerAmberWarning,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        VerificationStatus.ACTION_REJECTED -> {
                            Text(
                                text = "REJECTED",
                                color = RockerRedError,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        VerificationStatus.PENDING -> {
                            Icon(
                                imageVector = Icons.Default.HourglassEmpty,
                                contentDescription = "Running",
                                tint = RockerCyanPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        else -> {
                            Text(
                                text = step.verificationStatus.name,
                                color = RockerAmberWarning,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (step.durationMs > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${step.durationMs}ms",
                            color = RockerTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Target
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "TARGET: ",
                    color = RockerTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = step.target,
                    color = RockerTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            if (step.thought.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "REASONING: \"${step.thought}\"",
                    color = RockerTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }

            if (step.observationAfter.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "OBSERVED: ${step.observationAfter}",
                    color = RockerTextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

private fun getActionVisuals(type: AgentActionType): Pair<ImageVector, Color> {
    return when (type) {
        AgentActionType.LAUNCH_APPLICATION -> Icons.Default.Code to RockerCyanPrimary
        AgentActionType.INSPECT_SCREEN -> Icons.Default.Visibility to RockerVioletSecondary
        AgentActionType.FIND_UI_ELEMENT -> Icons.Default.Search to RockerCyanPrimary
        AgentActionType.CLICK_ELEMENT -> Icons.Default.TouchApp to RockerGreenSuccess
        AgentActionType.ENTER_TEXT -> Icons.Default.Code to RockerCyanPrimary
        AgentActionType.VERIFY_CONDITION -> Icons.Default.CheckCircle to RockerGreenSuccess
        else -> Icons.Default.Code to RockerTextSecondary
    }
}
