package com.example.ai

import com.example.accessibility.AccessibilityBridge
import com.example.model.ScreenSnapshot
import com.example.model.UiElement
import com.example.model.UiRole

enum class ObstacleType {
    ACCOUNT_DIALOG,
    ONBOARDING_TERMS,
    AD_OVERLAY,
    COOKIE_CONSENT,
    PERMISSION_DIALOG
}

data class InterstitialObstacle(
    val type: ObstacleType,
    val title: String,
    val dismissElementId: String,
    val dismissLabel: String
)

data class ScreenComprehension(
    val packageName: String,
    val dominantGoal: String,
    val searchBarElement: UiElement?,
    val primaryActionButton: UiElement?,
    val listItems: List<UiElement>,
    val inputFields: List<UiElement>,
    val detectedObstacle: InterstitialObstacle?,
    val isPlaybackActive: Boolean,
    val isResultsListVisible: Boolean,
    val isDialogPresented: Boolean,
    val descriptionSummary: String
)

class ScreenUnderstandingEngine {

    fun detectInterstitialObstacle(snapshot: ScreenSnapshot): InterstitialObstacle? {
        for (el in snapshot.elements) {
            val label = "${el.text} ${el.contentDescription ?: ""} ${el.viewIdResourceName ?: ""}".lowercase().trim()

            // 1. Account / Sign-in prompt (e.g. Chrome "Use without an account", "Turn on sync")
            if (el.isClickable && (label.contains("use without an account") || label.contains("continue without an account") || label.contains("continue as guest") || label.contains("without an account") || label == "no thanks" || label == "not now")) {
                return InterstitialObstacle(ObstacleType.ACCOUNT_DIALOG, "Account Setup Dialog", el.id, el.text.ifBlank { "Use without account" })
            }

            // 2. Terms of service onboarding (e.g. Chrome "Accept and continue")
            if (el.isClickable && (label.contains("accept & continue") || label.contains("accept and continue") || label == "i agree" || label == "agree" || label == "get started" || label == "got it")) {
                return InterstitialObstacle(ObstacleType.ONBOARDING_TERMS, "Terms & Onboarding Dialog", el.id, el.text.ifBlank { "Accept and continue" })
            }

            // 3. Ad popups or interstitials
            if (el.isClickable && (label.contains("skip ad") || label == "skip" || label.contains("close ad") || label == "close" || label == "dismiss" || label == "✕")) {
                return InterstitialObstacle(ObstacleType.AD_OVERLAY, "Advertisement Modal", el.id, el.text.ifBlank { "Skip / Close" })
            }

            // 4. Permissions
            if (el.isClickable && (label.contains("while using the app") || label == "allow" || label == "only this time")) {
                return InterstitialObstacle(ObstacleType.PERMISSION_DIALOG, "System Permission Modal", el.id, el.text.ifBlank { "Allow" })
            }
        }
        return null
    }

    fun findFirstOrganicResultLink(snapshot: ScreenSnapshot, query: String? = null): UiElement? {
        val ignore = setOf("search", "google", "all", "images", "videos", "news", "maps", "shopping", "tools", "filter", "sign in", "clear")
        return snapshot.elements.firstOrNull { el ->
            val label = "${el.text} ${el.contentDescription ?: ""}".trim().lowercase()
            val isClickable = el.isClickable
            val notIgnore = ignore.none { label == it }
            val isLink = el.role == UiRole.LIST_ITEM || label.contains(".com") || label.contains("http") || label.contains("official") || label.contains("wiki") || label.contains("wwe") || el.boundsTop > 200
            isClickable && notIgnore && isLink
        }
    }

    fun getCurrentSnapshot(expectedPackage: String? = null): ScreenSnapshot {
        val realSnapshot = AccessibilityBridge.currentSnapshot.value
        if (AccessibilityBridge.isServiceConnected.value && realSnapshot != null && realSnapshot.elements.isNotEmpty()) {
            return redactSensitiveInformation(realSnapshot)
        }

        // Production requirement: Never report fabricated sandbox screens as real device state
        val statusMsg = if (!AccessibilityBridge.isServiceConnected.value) {
            "Accessibility Service is not enabled. Screen hierarchy unavailable."
        } else {
            "No interactive accessibility elements detected in active window."
        }

        return ScreenSnapshot(
            packageName = expectedPackage ?: realSnapshot?.packageName ?: "unknown",
            elements = emptyList(),
            timestamp = System.currentTimeMillis(),
            summary = statusMsg,
            isRealAccessibility = AccessibilityBridge.isServiceConnected.value
        )
    }

    fun redactSensitiveInformation(text: String): String {
        return text
            .replace(Regex("(?i)\\b(otp|code)\\s*(is|:)?\\s*(\\d{4,8})\\b"), "$1 $2 [REDACTED_OTP]")
            .replace(Regex("(?i)\\b(password|pass|pwd)\\s*(is|:)?\\s*([\\S]{4,})\\b"), "$1 $2 [REDACTED_PASSWORD]")
            .replace(Regex("(?i)\\b(pin)\\s*(is|:)?\\s*(\\d{4,6})\\b"), "$1 $2 [REDACTED_PIN]")
    }

    fun redactSensitiveInformation(snapshot: ScreenSnapshot): ScreenSnapshot {
        val safeElements = snapshot.elements.map { el ->
            val isSensitive = el.className.contains("Password", true) ||
                    (el.viewIdResourceName?.contains("password", true) == true) ||
                    (el.viewIdResourceName?.contains("otp", true) == true) ||
                    (el.viewIdResourceName?.contains("pin", true) == true)

            if (isSensitive) {
                el.copy(text = "[REDACTED_SENSITIVE]", contentDescription = "[REDACTED_SENSITIVE]")
            } else {
                el.copy(
                    text = redactSensitiveInformation(el.text),
                    contentDescription = el.contentDescription?.let { redactSensitiveInformation(it) }
                )
            }
        }
        return snapshot.copy(elements = safeElements)
    }

    fun analyzeScreen(snapshot: ScreenSnapshot): ScreenComprehension {
        var searchBar: UiElement? = null
        var primaryAction: UiElement? = null
        val items = mutableListOf<UiElement>()
        val inputs = mutableListOf<UiElement>()
        var isPlayback = false
        var isResults = false
        var isDialog = false

        for (el in snapshot.elements) {
            val combined = "${el.text} ${el.contentDescription ?: ""} ${el.viewIdResourceName ?: ""}".lowercase()

            if (el.role == UiRole.SEARCH_BAR || combined.contains("search") || (el.isEditable && combined.contains("query"))) {
                if (searchBar == null) searchBar = el
            }

            if (el.isEditable || el.role == UiRole.INPUT_FIELD) {
                inputs.add(el)
            }

            if (el.role == UiRole.BUTTON || el.isClickable) {
                if (combined.contains("send") || combined.contains("play") || combined.contains("submit") || combined.contains("done") || combined.contains("shutter") || combined.contains("equals")) {
                    primaryAction = el
                }
            }

            if (el.role == UiRole.LIST_ITEM || combined.contains("item") || combined.contains("video") || combined.contains("result")) {
                items.add(el)
            }

            if (combined.contains("pause") || combined.contains("playing") || combined.contains("now playing")) {
                isPlayback = true
            }

            if (combined.contains("views") || combined.contains("results") || combined.contains("duration")) {
                isResults = true
            }

            if (combined.contains("permission") || combined.contains("allow") || combined.contains("cancel")) {
                isDialog = true
            }
        }

        val summary = buildString {
            append("Screen [${snapshot.packageName}]: ")
            if (searchBar != null) append("Search bar present. ")
            if (items.isNotEmpty()) append("${items.size} list/result items. ")
            if (inputs.isNotEmpty()) append("${inputs.size} input fields. ")
            if (isPlayback) append("Playback detected. ")
        }

        val obstacle = detectInterstitialObstacle(snapshot)

        return ScreenComprehension(
            packageName = snapshot.packageName,
            dominantGoal = if (obstacle != null) "Resolve ${obstacle.title}" else if (isPlayback) "Media Playback" else if (isResults) "Browsing Results" else "App Navigation",
            searchBarElement = searchBar,
            primaryActionButton = primaryAction,
            listItems = items,
            inputFields = inputs,
            detectedObstacle = obstacle,
            isPlaybackActive = isPlayback,
            isResultsListVisible = isResults,
            isDialogPresented = isDialog || obstacle != null,
            descriptionSummary = summary + (if (obstacle != null) "Obstacle detected: ${obstacle.title}. " else "")
        )
    }

    fun generateSandboxSnapshot(appNameOrPackage: String, screenState: String = "HOME", query: String = ""): ScreenSnapshot {
        val target = appNameOrPackage.lowercase()
        val elements = mutableListOf<UiElement>()

        val pkg: String
        when {
            target.contains("calc") -> {
                pkg = "com.google.android.calculator"
                elements.add(UiElement("calc_display", text = if (query.isNotBlank()) query else "0", role = UiRole.TITLE, boundsLeft = 32, boundsTop = 80, boundsRight = 1000, boundsBottom = 260))
                elements.add(UiElement("btn_clear", text = "AC", isClickable = true, role = UiRole.BUTTON, boundsLeft = 40, boundsTop = 320, boundsRight = 240, boundsBottom = 450))
                elements.add(UiElement("btn_plus", text = "+", isClickable = true, role = UiRole.BUTTON, boundsLeft = 780, boundsTop = 320, boundsRight = 980, boundsBottom = 450))
                elements.add(UiElement("btn_minus", text = "-", isClickable = true, role = UiRole.BUTTON, boundsLeft = 780, boundsTop = 480, boundsRight = 980, boundsBottom = 610))
                elements.add(UiElement("btn_multiply", text = "×", isClickable = true, role = UiRole.BUTTON, boundsLeft = 780, boundsTop = 640, boundsRight = 980, boundsBottom = 770))
                elements.add(UiElement("btn_equals", text = "=", isClickable = true, role = UiRole.BUTTON, boundsLeft = 780, boundsTop = 800, boundsRight = 980, boundsBottom = 930))
                elements.add(UiElement("btn_7", text = "7", isClickable = true, role = UiRole.BUTTON, boundsLeft = 40, boundsTop = 480, boundsRight = 240, boundsBottom = 610))
                elements.add(UiElement("btn_8", text = "8", isClickable = true, role = UiRole.BUTTON, boundsLeft = 280, boundsTop = 480, boundsRight = 480, boundsBottom = 610))
                elements.add(UiElement("btn_9", text = "9", isClickable = true, role = UiRole.BUTTON, boundsLeft = 520, boundsTop = 480, boundsRight = 720, boundsBottom = 610))
                elements.add(UiElement("btn_4", text = "4", isClickable = true, role = UiRole.BUTTON, boundsLeft = 40, boundsTop = 640, boundsRight = 240, boundsBottom = 770))
                elements.add(UiElement("btn_5", text = "5", isClickable = true, role = UiRole.BUTTON, boundsLeft = 280, boundsTop = 640, boundsRight = 480, boundsBottom = 770))
                elements.add(UiElement("btn_6", text = "6", isClickable = true, role = UiRole.BUTTON, boundsLeft = 520, boundsTop = 640, boundsRight = 720, boundsBottom = 770))
            }
            target.contains("camera") -> {
                pkg = "com.android.camera"
                elements.add(UiElement("cam_viewfinder", text = "Live Viewfinder", role = UiRole.CONTAINER, boundsLeft = 0, boundsTop = 100, boundsRight = 1080, boundsBottom = 1600))
                elements.add(UiElement("btn_shutter", text = "Take Photo", contentDescription = "Shutter Button", isClickable = true, role = UiRole.BUTTON, boundsLeft = 460, boundsTop = 1680, boundsRight = 620, boundsBottom = 1840))
                elements.add(UiElement("btn_switch_cam", text = "Switch Camera", isClickable = true, role = UiRole.BUTTON, boundsLeft = 840, boundsTop = 1700, boundsRight = 980, boundsBottom = 1820))
                elements.add(UiElement("btn_gallery_thumb", text = "Recent Photos", isClickable = true, role = UiRole.BUTTON, boundsLeft = 80, boundsTop = 1700, boundsRight = 220, boundsBottom = 1820))
            }
            target.contains("clock") || target.contains("deskclock") -> {
                pkg = "com.google.android.deskclock"
                elements.add(UiElement("tab_alarm", text = "Alarm", isClickable = true, role = UiRole.TAB, boundsLeft = 40, boundsTop = 60, boundsRight = 280, boundsBottom = 130))
                elements.add(UiElement("tab_clock", text = "Clock", isClickable = true, role = UiRole.TAB, boundsLeft = 300, boundsTop = 60, boundsRight = 540, boundsBottom = 130))
                elements.add(UiElement("tab_timer", text = "Timer", isClickable = true, role = UiRole.TAB, boundsLeft = 560, boundsTop = 60, boundsRight = 800, boundsBottom = 130))
                elements.add(UiElement("alarm_item_1", text = "6:30 AM • Weekdays", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 40, boundsTop = 180, boundsRight = 1000, boundsBottom = 300))
                elements.add(UiElement("alarm_item_2", text = "8:00 AM • Weekends", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 40, boundsTop = 320, boundsRight = 1000, boundsBottom = 440))
                elements.add(UiElement("btn_add_alarm", text = "+ Add Alarm", contentDescription = "Add Alarm", isClickable = true, role = UiRole.BUTTON, boundsLeft = 460, boundsTop = 1680, boundsRight = 620, boundsBottom = 1840))
            }
            target.contains("note") || target.contains("keep") -> {
                pkg = "com.google.android.keep"
                elements.add(UiElement("keep_search", text = "Search your notes", role = UiRole.SEARCH_BAR, boundsLeft = 40, boundsTop = 60, boundsRight = 1000, boundsBottom = 140))
                elements.add(UiElement("note_item_1", text = "Project Ideas • Rocker AI on Snapdragon 8s Gen 3", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 40, boundsTop = 180, boundsRight = 500, boundsBottom = 400))
                elements.add(UiElement("note_item_2", text = "Groceries • Milk, Eggs, Coffee", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 540, boundsTop = 180, boundsRight = 1000, boundsBottom = 400))
                elements.add(UiElement("btn_new_note", text = "+ New Note", isClickable = true, role = UiRole.BUTTON, boundsLeft = 860, boundsTop = 1680, boundsRight = 1000, boundsBottom = 1820))
            }
            target.contains("youtube") -> {
                pkg = "com.google.android.youtube"
                when (screenState) {
                    "HOME" -> {
                        elements.add(UiElement("yt_logo", "YouTube", role = UiRole.TITLE, boundsLeft = 32, boundsTop = 64, boundsRight = 200, boundsBottom = 120))
                        elements.add(UiElement("yt_search_btn", "Search", contentDescription = "Search YouTube", isClickable = true, role = UiRole.SEARCH_BAR, boundsLeft = 800, boundsTop = 64, boundsRight = 950, boundsBottom = 120))
                        elements.add(UiElement("yt_feed_1", "Trending Music Mix 2026 • 2.4M views", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 160, boundsRight = 1000, boundsBottom = 500))
                        elements.add(UiElement("yt_feed_2", "Tech Innovations: Snapdragon 8s Gen 3 Deep Dive", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 520, boundsRight = 1000, boundsBottom = 860))
                    }
                    "SEARCH_TYPED" -> {
                        elements.add(UiElement("yt_search_input", text = query.ifBlank { "Arijit Singh" }, isEditable = true, role = UiRole.INPUT_FIELD, boundsLeft = 120, boundsTop = 64, boundsRight = 850, boundsBottom = 120))
                        elements.add(UiElement("yt_search_submit", "Search", isClickable = true, role = UiRole.BUTTON, boundsLeft = 860, boundsTop = 64, boundsRight = 1000, boundsBottom = 120))
                    }
                    "SEARCH_RESULTS" -> {
                        elements.add(UiElement("yt_result_1", "Arijit Singh - Latest Official Acoustic Hits 2026", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 140, boundsRight = 1000, boundsBottom = 380))
                        elements.add(UiElement("yt_result_2", "Believer - Imagine Dragons (Official Audio)", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 400, boundsRight = 1000, boundsBottom = 640))
                        elements.add(UiElement("yt_result_3", "Arijit Singh Live Concert Kolkata", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 660, boundsRight = 1000, boundsBottom = 900))
                    }
                    else -> {
                        elements.add(UiElement("yt_player", "Now Playing: Arijit Singh - Official Acoustic Hits", role = UiRole.TITLE, boundsLeft = 0, boundsTop = 100, boundsRight = 1080, boundsBottom = 700))
                        elements.add(UiElement("yt_pause_btn", "Pause", isClickable = true, role = UiRole.BUTTON, boundsLeft = 480, boundsTop = 750, boundsRight = 600, boundsBottom = 850))
                        elements.add(UiElement("yt_like_btn", "Like (142K)", isClickable = true, role = UiRole.BUTTON, boundsLeft = 60, boundsTop = 870, boundsRight = 250, boundsBottom = 940))
                    }
                }
            }
            target.contains("whatsapp") -> {
                pkg = "com.whatsapp"
                when (screenState) {
                    "HOME" -> {
                        elements.add(UiElement("wa_title", "WhatsApp", role = UiRole.TITLE, boundsLeft = 32, boundsTop = 64, boundsRight = 240, boundsBottom = 120))
                        elements.add(UiElement("wa_search_btn", "Search contacts and chats", isClickable = true, role = UiRole.SEARCH_BAR, boundsLeft = 800, boundsTop = 64, boundsRight = 950, boundsBottom = 120))
                        elements.add(UiElement("wa_chat_1", "Rahul Sharma: Hey, are we meeting today?", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 150, boundsRight = 1000, boundsBottom = 260))
                        elements.add(UiElement("wa_chat_2", "Alex Rivera: Shared the presentation file", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 270, boundsRight = 1000, boundsBottom = 380))
                    }
                    "CHAT" -> {
                        elements.add(UiElement("wa_chat_header", "Chat with Rahul", role = UiRole.TITLE, boundsLeft = 120, boundsTop = 64, boundsRight = 600, boundsBottom = 120))
                        elements.add(UiElement("wa_msg_input", text = query, isEditable = true, role = UiRole.INPUT_FIELD, boundsLeft = 32, boundsTop = 1800, boundsRight = 900, boundsBottom = 1920))
                        elements.add(UiElement("wa_send_btn", "Send", isClickable = true, role = UiRole.BUTTON, boundsLeft = 920, boundsTop = 1800, boundsRight = 1040, boundsBottom = 1920))
                    }
                    else -> {
                        elements.add(UiElement("wa_sent_bubble", "Message Delivered ✓✓", role = UiRole.TITLE, boundsLeft = 300, boundsTop = 1400, boundsRight = 1000, boundsBottom = 1500))
                    }
                }
            }
            target.contains("chrome") || target.contains("browser") -> {
                pkg = "com.android.chrome"
                when (screenState) {
                    "ACCOUNT_PROMPT", "ONBOARDING" -> {
                        elements.add(UiElement("chrome_welcome", "Welcome to Chrome", role = UiRole.TITLE, boundsLeft = 32, boundsTop = 200, boundsRight = 1000, boundsBottom = 300))
                        elements.add(UiElement("chrome_sync_title", "Turn on sync to get your passwords and bookmarks on all devices", role = UiRole.CONTAINER, boundsLeft = 32, boundsTop = 320, boundsRight = 1000, boundsBottom = 480))
                        elements.add(UiElement("btn_without_account", "Use without an account", isClickable = true, role = UiRole.BUTTON, boundsLeft = 80, boundsTop = 1600, boundsRight = 1000, boundsBottom = 1720))
                        elements.add(UiElement("btn_accept_continue", "Accept & continue", isClickable = true, role = UiRole.BUTTON, boundsLeft = 80, boundsTop = 1740, boundsRight = 1000, boundsBottom = 1860))
                    }
                    "AD_POPUP" -> {
                        elements.add(UiElement("ad_badge", text = "Sponsored Advertisement", role = UiRole.TITLE, boundsLeft = 32, boundsTop = 300, boundsRight = 600, boundsBottom = 380))
                        elements.add(UiElement("btn_skip_ad", text = "Skip Ad", isClickable = true, role = UiRole.BUTTON, boundsLeft = 800, boundsTop = 320, boundsRight = 1020, boundsBottom = 420))
                        elements.add(UiElement("btn_close_ad", text = "Close", isClickable = true, role = UiRole.BUTTON, boundsLeft = 900, boundsTop = 100, boundsRight = 1020, boundsBottom = 200))
                    }
                    "SEARCH_RESULTS" -> {
                        val q = query.ifBlank { "wwe superstar" }
                        elements.add(UiElement("url_bar", text = "https://www.google.com/search?q=$q", isEditable = true, role = UiRole.SEARCH_BAR, boundsLeft = 32, boundsTop = 60, boundsRight = 950, boundsBottom = 140))
                        elements.add(UiElement("search_header", text = "Google Search Results: $q", role = UiRole.TITLE, boundsLeft = 32, boundsTop = 160, boundsRight = 1000, boundsBottom = 240))
                        elements.add(UiElement("first_site_link", text = "WWE Superstars | Official WWE Roster & News (wwe.com)", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 260, boundsRight = 1000, boundsBottom = 420))
                        elements.add(UiElement("first_site_snippet", text = "Meet the Superstars of Raw, SmackDown, and NXT: Roman Reigns, Cody Rhodes, Rhea Ripley, Seth Rollins.", role = UiRole.CONTAINER, boundsLeft = 32, boundsTop = 430, boundsRight = 1000, boundsBottom = 540))
                        elements.add(UiElement("second_site_link", text = "List of current WWE personnel - Wikipedia", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 560, boundsRight = 1000, boundsBottom = 720))
                    }
                    "SITE_OPENED" -> {
                        elements.add(UiElement("site_url", text = "https://www.wwe.com/superstars", role = UiRole.SEARCH_BAR, boundsLeft = 32, boundsTop = 60, boundsRight = 950, boundsBottom = 140))
                        elements.add(UiElement("site_header", text = "WWE.com - Official Superstars Roster", role = UiRole.TITLE, boundsLeft = 32, boundsTop = 160, boundsRight = 1000, boundsBottom = 260))
                        elements.add(UiElement("roster_item_1", text = "Cody Rhodes • Undisputed WWE Champion", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 280, boundsRight = 1000, boundsBottom = 440))
                        elements.add(UiElement("roster_item_2", text = "Roman Reigns • The Original Tribal Chief", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 460, boundsRight = 1000, boundsBottom = 620))
                        elements.add(UiElement("roster_item_3", text = "Rhea Ripley • Women's World Champion", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 640, boundsRight = 1000, boundsBottom = 800))
                    }
                    else -> {
                        elements.add(UiElement("url_bar", text = "Search or type URL", isEditable = true, role = UiRole.SEARCH_BAR, boundsLeft = 32, boundsTop = 60, boundsRight = 950, boundsBottom = 140))
                        elements.add(UiElement("search_results", text = "Google", role = UiRole.TITLE, boundsLeft = 450, boundsTop = 300, boundsRight = 630, boundsBottom = 380))
                        elements.add(UiElement("feed_card", text = "Trending: Qualcomm Snapdragon 8s Gen 3 Device Innovations", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 500, boundsRight = 1000, boundsBottom = 680))
                    }
                }
            }
            else -> {
                pkg = "com.android.settings"
                elements.add(UiElement("app_title", "Settings", role = UiRole.TITLE, boundsLeft = 32, boundsTop = 64, boundsRight = 400, boundsBottom = 120))
                elements.add(UiElement("search_field", "Search settings & options", isClickable = true, role = UiRole.SEARCH_BAR, boundsLeft = 32, boundsTop = 150, boundsRight = 1000, boundsBottom = 250))
                elements.add(UiElement("opt_1", "Network & Internet (Wi-Fi, Mobile)", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 280, boundsRight = 1000, boundsBottom = 380))
                elements.add(UiElement("opt_2", "Connected devices (Bluetooth, NFC)", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 400, boundsRight = 1000, boundsBottom = 500))
                elements.add(UiElement("opt_3", "Battery & Power Management", isClickable = true, role = UiRole.LIST_ITEM, boundsLeft = 32, boundsTop = 520, boundsRight = 1000, boundsBottom = 620))
            }
        }

        return ScreenSnapshot(
            packageName = pkg,
            elements = elements,
            timestamp = System.currentTimeMillis(),
            summary = "Snapshot of $pkg ($screenState)"
        )
    }
}
