package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ai.WakeState
import com.example.ui.theme.OrbExecutingGlow
import com.example.ui.theme.OrbIdleGlow
import com.example.ui.theme.OrbListeningGlow
import com.example.ui.theme.OrbReasoningGlow
import com.example.ui.theme.RockerCyanPrimary
import com.example.ui.theme.RockerVioletSecondary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VoiceOrb(
    wakeState: WakeState,
    audioEnergy: Float,
    isExecuting: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 190.dp,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation_angle"
    )

    val targetGlowColor = when {
        isExecuting -> OrbExecutingGlow
        wakeState == WakeState.CAPTURING_SPEECH -> OrbListeningGlow
        wakeState == WakeState.PROCESSING || wakeState == WakeState.WAKE_DETECTED -> OrbReasoningGlow
        wakeState == WakeState.LISTENING_FOR_WAKE_WORD -> RockerCyanPrimary
        else -> OrbIdleGlow
    }

    val glowColor by animateColorAsState(targetValue = targetGlowColor, label = "orb_color")

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .testTag("voice_orb_button")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = size / 2),
                onClick = onClick
            )
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = this.size.minDimension / 2.8f
            val dynamicRadius = baseRadius * pulseScale * (1f + audioEnergy * 0.4f)

            // Outer Atmospheric Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        glowColor.copy(alpha = 0.35f),
                        glowColor.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = dynamicRadius * 1.5f
                ),
                radius = dynamicRadius * 1.5f,
                center = center
            )

            // Outer Pulse Ring 1
            drawCircle(
                color = glowColor.copy(alpha = 0.45f),
                radius = dynamicRadius * 1.15f,
                center = center,
                style = Stroke(width = 2.5f)
            )

            // Outer Pulse Ring 2 with dotted acoustic points
            val dotsCount = 12
            for (i in 0 until dotsCount) {
                val angle = Math.toRadians((i * (360.0 / dotsCount) + rotationAngle).toDouble())
                val dotX = center.x + (dynamicRadius * 1.25f * cos(angle)).toFloat()
                val dotY = center.y + (dynamicRadius * 1.25f * sin(angle)).toFloat()
                drawCircle(
                    color = glowColor.copy(alpha = 0.7f),
                    radius = 3.5f + (audioEnergy * 4f),
                    center = Offset(dotX, dotY)
                )
            }

            // Core Solid Gradient Orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        glowColor,
                        RockerVioletSecondary.copy(alpha = 0.85f),
                        Color(0xFF070B14)
                    ),
                    center = center,
                    radius = dynamicRadius
                ),
                radius = dynamicRadius,
                center = center
            )

            // Inner Cybernetic Ring
            drawCircle(
                color = Color.White.copy(alpha = 0.75f),
                radius = dynamicRadius * 0.7f,
                center = center,
                style = Stroke(width = 1.8f)
            )
        }
    }
}
