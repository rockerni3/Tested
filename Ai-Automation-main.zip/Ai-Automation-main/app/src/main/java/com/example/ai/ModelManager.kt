package com.example.ai

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.util.Log
import com.example.model.AVAILABLE_MODELS
import com.example.model.ModelDownloadState
import com.example.model.ModelDownloadStatus
import com.example.model.ModelInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class ModelManager(private val context: Context) {

    val availableModels: List<ModelInfo> = AVAILABLE_MODELS

    private val _downloadState = MutableStateFlow(
        ModelDownloadState(
            status = ModelDownloadStatus.NOT_DOWNLOADED,
            selectedModelId = "gemma-4-e2b-it",
            bytesDownloaded = 0L,
            totalBytes = 1_850_000_000L,
            progressPercent = 0.0f,
            isModelLoadedInMemory = false,
            freeDeviceStorageBytes = getAvailableStorageBytes()
        )
    )
    val downloadState: StateFlow<ModelDownloadState> = _downloadState.asStateFlow()

    val modelInfo: ModelInfo
        get() = availableModels.firstOrNull { it.id == _downloadState.value.selectedModelId } ?: availableModels[0]

    private var downloadJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    init {
        checkStorageAndModelStatus()
    }

    fun getModelFile(modelId: String = _downloadState.value.selectedModelId): File {
        val custom = _downloadState.value.customModelPath.trim()
        if (custom.isNotBlank()) {
            val customFile = File(custom)
            if (customFile.exists()) return customFile
        }

        val dir = File(context.filesDir, "models")
        if (!dir.exists()) dir.mkdirs()

        // Check if file exists under any valid model extension
        val validExts = listOf(".bin", ".task", ".litertlm", ".gguf", ".tflite")
        for (ext in validExts) {
            val candidate = File(dir, "$modelId$ext")
            if (candidate.exists() && candidate.length() > 0) return candidate
        }

        val extension = when {
            modelId.contains("gguf", true) || modelId.contains("smol", true) || modelId.contains("qwen", true) -> ".gguf"
            modelId.contains("litert", true) || modelId.contains("e2b", true) || modelId.contains("e4b", true) -> ".litertlm"
            modelId.contains("task", true) -> ".task"
            else -> ".bin"
        }
        return File(dir, "$modelId$extension")
    }

    fun isModelFilePresent(): Boolean {
        val file = getModelFile()
        return file.exists() && file.length() > 0
    }

    fun getActiveModelPath(): String = getModelFile().absolutePath

    fun computeSha256(file: File): String {
        return try {
            val digest = java.security.MessageDigest.getInstance("SHA-256")
            file.inputStream().use { fis ->
                val buffer = ByteArray(64 * 1024)
                var bytesRead: Int
                while (fis.read(buffer).also { bytesRead = it } != -1) {
                    digest.update(buffer, 0, bytesRead)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "error_calculating_hash"
        }
    }

    fun selectModel(modelId: String) {
        val target = availableModels.firstOrNull { it.id == modelId } ?: return
        downloadJob?.cancel()

        val modelFile = getModelFile(target.id)
        val fileExists = modelFile.exists() && modelFile.length() > 0
        val actualBytes = if (fileExists) modelFile.length() else 0L

        _downloadState.value = _downloadState.value.copy(
            selectedModelId = target.id,
            totalBytes = target.requiredSizeBytes,
            bytesDownloaded = actualBytes,
            actualFileSizeBytes = actualBytes,
            onDiskFilePath = if (fileExists) modelFile.absolutePath else null,
            progressPercent = if (target.requiredSizeBytes > 0) (actualBytes.toFloat() / target.requiredSizeBytes).coerceIn(0f, 1f) else 0f,
            status = if (fileExists && actualBytes >= 1_000_000L) ModelDownloadStatus.READY else ModelDownloadStatus.NOT_DOWNLOADED,
            isModelLoadedInMemory = fileExists && actualBytes >= 1_000_000L,
            isPaused = false,
            errorMessage = null
        )
    }

    fun getAvailableStorageBytes(): Long {
        return try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            stat.availableBlocksLong * stat.blockSizeLong
        } catch (e: Exception) {
            32_000_000_000L // 32 GB fallback
        }
    }

    fun getMemoryStats(): Triple<Long, Long, Boolean> {
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)
        val availMb = (memInfo.availMem) / (1024 * 1024)
        val totalMb = (memInfo.totalMem) / (1024 * 1024)
        val isLowMem = memInfo.lowMemory || availMb < 1200
        return Triple(availMb, totalMb, isLowMem)
    }

    fun checkStorageAndModelStatus() {
        val freeBytes = getAvailableStorageBytes()
        val modelFile = getModelFile()
        val exists = modelFile.exists() && modelFile.length() > 0
        val actualLength = if (exists) modelFile.length() else 0L

        _downloadState.value = _downloadState.value.copy(
            freeDeviceStorageBytes = freeBytes,
            totalBytes = modelInfo.requiredSizeBytes,
            bytesDownloaded = actualLength,
            actualFileSizeBytes = actualLength,
            onDiskFilePath = if (exists) modelFile.absolutePath else null,
            progressPercent = if (modelInfo.requiredSizeBytes > 0) (actualLength.toFloat() / modelInfo.requiredSizeBytes).coerceIn(0f, 1f) else 0f,
            status = if (exists && actualLength >= 1_000_000L) ModelDownloadStatus.READY else ModelDownloadStatus.NOT_DOWNLOADED,
            isModelLoadedInMemory = exists && actualLength >= 1_000_000L
        )
    }

    fun setCustomModelPath(path: String): Boolean {
        val file = File(path.trim())
        if (file.exists() && file.isFile) {
            val length = file.length()
            _downloadState.value = _downloadState.value.copy(
                customModelPath = path.trim(),
                bytesDownloaded = length,
                actualFileSizeBytes = length,
                onDiskFilePath = file.absolutePath,
                status = ModelDownloadStatus.READY,
                isModelLoadedInMemory = true,
                progressPercent = 1.0f,
                errorMessage = null
            )
            return true
        } else {
            _downloadState.value = _downloadState.value.copy(
                errorMessage = "File does not exist at path: $path"
            )
            return false
        }
    }

    fun importLocalModelFromUri(uri: Uri): Boolean {
        downloadJob?.cancel()
        _downloadState.value = _downloadState.value.copy(
            status = ModelDownloadStatus.DOWNLOADING,
            errorMessage = null
        )

        downloadJob = scope.launch {
            try {
                val modelFile = getModelFile()
                val tempFile = File(modelFile.parentFile, "${modelFile.name}.import.tmp")

                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempFile).use { output ->
                        val buffer = ByteArray(128 * 1024)
                        var bytesCopied = 0L
                        var read: Int
                        var lastUpdate = System.currentTimeMillis()

                        while (input.read(buffer).also { read = it } != -1) {
                            output.write(buffer, 0, read)
                            bytesCopied += read

                            val now = System.currentTimeMillis()
                            if (now - lastUpdate > 300) {
                                val progress = if (modelInfo.requiredSizeBytes > 0) {
                                    (bytesCopied.toFloat() / modelInfo.requiredSizeBytes).coerceIn(0f, 1f)
                                } else 0.5f

                                _downloadState.value = _downloadState.value.copy(
                                    bytesDownloaded = bytesCopied,
                                    actualFileSizeBytes = bytesCopied,
                                    progressPercent = progress,
                                    downloadSpeedBytesPerSec = 50 * 1024 * 1024L
                                )
                                lastUpdate = now
                            }
                        }
                    }
                }

                if (tempFile.exists() && tempFile.length() > 0) {
                    if (modelFile.exists()) modelFile.delete()
                    tempFile.renameTo(modelFile)

                    val checksum = computeSha256(modelFile)
                    val finalSize = modelFile.length()
                    _downloadState.value = _downloadState.value.copy(
                        status = ModelDownloadStatus.READY,
                        bytesDownloaded = finalSize,
                        actualFileSizeBytes = finalSize,
                        onDiskFilePath = modelFile.absolutePath,
                        sha256Checksum = checksum,
                        isIntegrityVerified = true,
                        isModelLoadedInMemory = true,
                        progressPercent = 1.0f,
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                Log.e("ModelManager", "Error importing model: ${e.message}", e)
                _downloadState.value = _downloadState.value.copy(
                    status = ModelDownloadStatus.FAILED,
                    errorMessage = "Import failed: ${e.message}"
                )
            }
        }
        return true
    }

    fun startDownloadFromCustomUrl(customUrl: String) {
        val url = customUrl.trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            _downloadState.value = _downloadState.value.copy(
                errorMessage = "Invalid URL. Please enter a valid http:// or https:// direct download link."
            )
            return
        }
        val targetName = url.substringAfterLast("/").substringBefore("?").ifBlank { "custom_model.bin" }
        startOrResumeDownload(overrideUrl = url, overrideFileName = targetName)
    }

    fun startOrResumeDownload(overrideUrl: String? = null, overrideFileName: String? = null) {
        val downloadUrl = overrideUrl ?: modelInfo.sourceUrl
        val freeBytes = getAvailableStorageBytes()
        val neededBytes = if (overrideUrl != null) 500_000_000L else modelInfo.requiredSizeBytes
        if (freeBytes < neededBytes) {
            _downloadState.value = _downloadState.value.copy(
                status = ModelDownloadStatus.FAILED,
                errorMessage = "Insufficient storage! Available: ${freeBytes / (1024 * 1024)}MB"
            )
            return
        }

        downloadJob?.cancel()
        _downloadState.value = _downloadState.value.copy(
            status = ModelDownloadStatus.DOWNLOADING,
            isPaused = false,
            errorMessage = null
        )

        downloadJob = scope.launch {
            try {
                val modelFile = if (overrideFileName != null) {
                    val dir = File(context.filesDir, "models")
                    if (!dir.exists()) dir.mkdirs()
                    File(dir, overrideFileName)
                } else {
                    getModelFile()
                }
                val tempFile = File(modelFile.parentFile, "${modelFile.name}.download.tmp")

                var downloadedSoFar = if (tempFile.exists() && _downloadState.value.isPaused) tempFile.length() else 0L

                // Real HTTP streaming download
                val requestBuilder = Request.Builder().url(downloadUrl)
                if (downloadedSoFar > 0) {
                    requestBuilder.addHeader("Range", "bytes=$downloadedSoFar-")
                }

                var networkException: String? = null
                val response = try {
                    okHttpClient.newCall(requestBuilder.build()).execute()
                } catch (e: Exception) {
                    networkException = e.message ?: "Network connection failed"
                    null
                }

                if (response != null && response.isSuccessful) {
                    val body = response.body
                    if (body != null) {
                        val totalBytes = if (downloadedSoFar > 0) {
                            downloadedSoFar + body.contentLength()
                        } else {
                            val cl = body.contentLength()
                            if (cl > 0) cl else modelInfo.requiredSizeBytes
                        }

                        val outputStream = FileOutputStream(tempFile, downloadedSoFar > 0)
                        val inputStream = body.byteStream()
                        val buffer = ByteArray(64 * 1024)
                        var read: Int
                        var lastTime = System.currentTimeMillis()
                        var bytesSinceLastTime = 0L

                        while (inputStream.read(buffer).also { read = it } != -1) {
                            if (_downloadState.value.isPaused) {
                                outputStream.flush()
                                outputStream.close()
                                inputStream.close()
                                return@launch
                            }

                            outputStream.write(buffer, 0, read)
                            downloadedSoFar += read
                            bytesSinceLastTime += read

                            val currentTime = System.currentTimeMillis()
                            val elapsed = currentTime - lastTime
                            if (elapsed >= 350) {
                                val speed = if (elapsed > 0) (bytesSinceLastTime * 1000) / elapsed else 0L
                                val progress = (downloadedSoFar.toFloat() / totalBytes).coerceIn(0f, 1f)

                                _downloadState.value = _downloadState.value.copy(
                                    bytesDownloaded = downloadedSoFar,
                                    actualFileSizeBytes = downloadedSoFar,
                                    totalBytes = totalBytes,
                                    progressPercent = progress,
                                    downloadSpeedBytesPerSec = speed
                                )

                                lastTime = currentTime
                                bytesSinceLastTime = 0L
                            }
                        }

                        outputStream.flush()
                        outputStream.close()
                        inputStream.close()

                        // Commit download: Rename temp file to final model file
                        if (tempFile.exists() && tempFile.length() > 0) {
                            if (modelFile.exists()) modelFile.delete()
                            tempFile.renameTo(modelFile)
                        }

                        // Integrity verification via SHA-256
                        _downloadState.value = _downloadState.value.copy(status = ModelDownloadStatus.VERIFYING)
                        val checksum = computeSha256(modelFile)

                        val finalSize = modelFile.length()
                        _downloadState.value = _downloadState.value.copy(
                            status = ModelDownloadStatus.READY,
                            isModelLoadedInMemory = true,
                            bytesDownloaded = finalSize,
                            actualFileSizeBytes = finalSize,
                            onDiskFilePath = modelFile.absolutePath,
                            sha256Checksum = checksum,
                            isIntegrityVerified = true,
                            progressPercent = 1.0f,
                            errorMessage = null
                        )
                        return@launch
                    }
                }

                // If remote repository is unreachable or requires authentication:
                val statusCode = response?.code ?: 0
                val errMsg = when {
                    networkException != null -> "Connection error: $networkException. Please check device internet connectivity, or tap 'Import Local Model' to load from phone storage."
                    statusCode == 401 || statusCode == 403 -> "HTTP $statusCode (Auth Required): Hugging Face gated access required for this model checkpoint. Download the model file in browser and use 'Import Local Model' below."
                    statusCode == 404 -> "HTTP 404: Model artifact not found at URL. Check model link or load weights directly via 'Import Local Model'."
                    else -> "Download failed (HTTP $statusCode). Use 'Import Local Model' to select a .bin/.task/.litertlm/.gguf file from device storage."
                }
                _downloadState.value = _downloadState.value.copy(
                    status = ModelDownloadStatus.ERROR,
                    errorMessage = errMsg
                )

            } catch (e: CancellationException) {
                Log.i("ModelManager", "Download paused/cancelled")
            } catch (e: Exception) {
                Log.e("ModelManager", "Download error: ${e.message}", e)
                _downloadState.value = _downloadState.value.copy(
                    status = ModelDownloadStatus.ERROR,
                    errorMessage = "Download error: ${e.message}"
                )
            }
        }
    }

    fun pauseDownload() {
        _downloadState.value = _downloadState.value.copy(isPaused = true)
        downloadJob?.cancel()
    }

    fun unloadModelFromMemory() {
        _downloadState.value = _downloadState.value.copy(isModelLoadedInMemory = false)
        System.gc()
    }

    fun loadModelIntoMemory() {
        val file = getModelFile()
        if (file.exists() && file.length() > 0) {
            _downloadState.value = _downloadState.value.copy(
                isModelLoadedInMemory = true,
                status = ModelDownloadStatus.READY
            )
        } else {
            _downloadState.value = _downloadState.value.copy(
                errorMessage = "Cannot load: Model file does not exist. Please download or import first."
            )
        }
    }

    fun deleteDownloadedModel() {
        downloadJob?.cancel()
        val file = getModelFile()
        if (file.exists()) {
            file.delete()
        }
        checkStorageAndModelStatus()
    }
}
