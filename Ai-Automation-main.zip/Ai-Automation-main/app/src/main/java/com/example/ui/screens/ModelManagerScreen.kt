package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.example.ai.DiagnosticInferenceResult
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ModelDownloadState
import com.example.model.ModelDownloadStatus
import com.example.model.ModelInfo
import com.example.ui.theme.RockerAmberWarning
import com.example.ui.theme.RockerBackground
import com.example.ui.theme.RockerBorder
import com.example.ui.theme.RockerCyanPrimary
import com.example.ui.theme.RockerGreenSuccess
import com.example.ui.theme.RockerRedError
import com.example.ui.theme.RockerSurface
import com.example.ui.theme.RockerSurfaceVariant
import com.example.ui.theme.RockerTextMuted
import com.example.ui.theme.RockerTextPrimary
import com.example.ui.theme.RockerTextSecondary
import com.example.ui.theme.RockerVioletSecondary

@Composable
fun ModelManagerScreen(
    modelState: ModelDownloadState,
    modelInfo: ModelInfo,
    availableModels: List<ModelInfo> = emptyList(),
    memoryStats: Triple<Long, Long, Boolean>,
    diagnosticResult: DiagnosticInferenceResult? = null,
    isDiagnosticRunning: Boolean = false,
    onRunDiagnostic: () -> Unit = {},
    onSelectModel: (String) -> Unit = {},
    onStartOrResumeDownload: () -> Unit,
    onPauseDownload: () -> Unit,
    onUnloadModel: () -> Unit,
    onLoadModel: () -> Unit,
    onRefreshMemory: () -> Unit,
    onImportLocalModel: (android.net.Uri) -> Unit = {},
    onSetCustomPath: (String) -> Boolean = { false },
    onDownloadFromUrl: (String) -> Unit = {},
    onDeleteModel: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var customPathInput by remember { mutableStateOf(modelState.customModelPath) }
    var customUrlInput by remember { mutableStateOf("") }
    var pathMessage by remember { mutableStateOf<String?>(null) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImportLocalModel(uri)
        }
    }

    val (availMb, totalMb, isLowMemory) = memoryStats
    val freeStorageGb = modelState.freeDeviceStorageBytes / (1024 * 1024 * 1024)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RockerBackground)
            .padding(16.dp)
    ) {
        // Target Hardware Profile Banner
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = RockerSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, RockerCyanPrimary.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = null,
                                tint = RockerCyanPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "QUALCOMM SNAPDRAGON 8s GEN 3",
                                color = RockerCyanPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = RockerGreenSuccess.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "POCO F6 OPTIMIZED",
                                color = RockerGreenSuccess,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "8 GB LPDDR5X RAM • Adreno 735 GPU • Qualcomm Hexagon NPU",
                        color = RockerTextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "The application implements proactive RAM guarding, dynamic model loading, and offline tool execution to prevent background service eviction.",
                        color = RockerTextMuted,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Live Memory & Storage Telemetry
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // RAM Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = RockerSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isLowMemory) RockerRedError else RockerBorder
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "AVAILABLE RAM", color = RockerTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            IconButton(onClick = onRefreshMemory, modifier = Modifier.size(16.dp)) {
                                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = RockerCyanPrimary)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${availMb} MB",
                            color = if (isLowMemory) RockerRedError else RockerGreenSuccess,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "of ${totalMb} MB total",
                            color = RockerTextMuted,
                            fontSize = 10.sp
                        )
                    }
                }

                // Storage Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = RockerSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "FREE STORAGE", color = RockerTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$freeStorageGb GB",
                            color = RockerTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Required: 1.82 GB",
                            color = RockerTextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Primary AI Model Details & Downloader
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = RockerSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PRIMARY AI MODEL",
                            color = RockerTextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = when {
                                modelState.actualFileSizeBytes > 0 -> RockerGreenSuccess.copy(alpha = 0.15f)
                                modelState.status == ModelDownloadStatus.DOWNLOADING -> RockerCyanPrimary.copy(alpha = 0.15f)
                                modelState.status == ModelDownloadStatus.ERROR || modelState.status == ModelDownloadStatus.FAILED -> RockerRedError.copy(alpha = 0.15f)
                                else -> RockerAmberWarning.copy(alpha = 0.15f)
                            }
                        ) {
                            Text(
                                text = when {
                                    modelState.actualFileSizeBytes > 0 -> "ON-DISK (${modelState.actualFileSizeBytes / (1024 * 1024)}MB)"
                                    modelState.status == ModelDownloadStatus.DOWNLOADING -> "DOWNLOADING..."
                                    modelState.status == ModelDownloadStatus.ERROR || modelState.status == ModelDownloadStatus.FAILED -> "ERROR / NEEDS IMPORT"
                                    else -> "NOT ON DISK (0 B)"
                                },
                                color = when {
                                    modelState.actualFileSizeBytes > 0 -> RockerGreenSuccess
                                    modelState.status == ModelDownloadStatus.DOWNLOADING -> RockerCyanPrimary
                                    modelState.status == ModelDownloadStatus.ERROR || modelState.status == ModelDownloadStatus.FAILED -> RockerRedError
                                    else -> RockerAmberWarning
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = modelInfo.name,
                        color = RockerTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = modelInfo.variant,
                        color = RockerCyanPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = modelInfo.description,
                        color = RockerTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Progress Bar
                    if (modelState.status == ModelDownloadStatus.DOWNLOADING || modelState.isPaused) {
                        LinearProgressIndicator(
                            progress = { modelState.progressPercent },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = RockerCyanPrimary,
                            trackColor = RockerSurfaceVariant,
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${(modelState.progressPercent * 100).toInt()}% (${modelState.bytesDownloaded / (1024 * 1024)} MB / ${modelState.totalBytes / (1024 * 1024)} MB)",
                                color = RockerTextMuted,
                                fontSize = 11.sp
                            )
                            Text(
                                text = if (modelState.isPaused) "Paused" else "45 MB/s",
                                color = RockerCyanPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (modelState.status == ModelDownloadStatus.DOWNLOADING) {
                            OutlinedButton(
                                onClick = onPauseDownload,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Pause, contentDescription = "Pause", tint = RockerCyanPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pause", color = RockerCyanPrimary)
                            }
                        } else {
                            ElevatedButton(
                                onClick = onStartOrResumeDownload,
                                colors = ButtonDefaults.elevatedButtonColors(
                                    containerColor = RockerCyanPrimary,
                                    contentColor = RockerBackground
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("download_model_button")
                            ) {
                                Icon(Icons.Default.CloudDownload, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    if (modelState.status == ModelDownloadStatus.READY) "Re-Download / Update" else "Download (~${modelInfo.requiredStorageMb} MB)",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (modelState.isModelLoadedInMemory) {
                            OutlinedButton(
                                onClick = onUnloadModel,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = RockerAmberWarning),
                                modifier = Modifier.testTag("unload_memory_button")
                            ) {
                                Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = RockerAmberWarning)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Free RAM", fontSize = 11.sp)
                            }
                        } else {
                            OutlinedButton(
                                onClick = onLoadModel,
                                modifier = Modifier.testTag("load_memory_button")
                            ) {
                                Icon(Icons.Default.Memory, contentDescription = null, tint = RockerCyanPrimary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Load", fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Real File Inspection & Local Model Import
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = RockerSurfaceVariant.copy(alpha = 0.6f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Folder, contentDescription = null, tint = RockerCyanPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "LOCAL MODEL FILE VERIFICATION",
                                        color = RockerTextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (modelState.actualFileSizeBytes > 0) RockerGreenSuccess.copy(alpha = 0.15f) else RockerAmberWarning.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = if (modelState.actualFileSizeBytes > 0) "FILE DETECTED" else "NO FILE ON DISK",
                                        color = if (modelState.actualFileSizeBytes > 0) RockerGreenSuccess else RockerAmberWarning,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Path: ${modelState.onDiskFilePath ?: "/data/user/0/com.example/files/models/${modelInfo.id}.bin"}",
                                color = RockerTextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 13.sp
                            )

                            Text(
                                text = "Actual Size: ${modelState.actualFileSizeBytes / (1024 * 1024)} MB (Required: ${modelInfo.requiredStorageMb} MB)",
                                color = if (modelState.actualFileSizeBytes > 0) RockerTextSecondary else RockerAmberWarning,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                ElevatedButton(
                                    onClick = { filePickerLauncher.launch(arrayOf("*/*")) },
                                    colors = ButtonDefaults.elevatedButtonColors(
                                        containerColor = RockerVioletSecondary,
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Import .bin / .gguf", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                if (modelState.actualFileSizeBytes > 0) {
                                    OutlinedButton(
                                        onClick = onDeleteModel,
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = RockerRedError),
                                        modifier = Modifier.weight(0.7f)
                                    ) {
                                        Text("Delete File", fontSize = 11.sp, color = RockerRedError)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Custom Absolute Path Input
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedTextField(
                                    value = customPathInput,
                                    onValueChange = {
                                        customPathInput = it
                                        pathMessage = null
                                    },
                                    placeholder = { Text("/sdcard/Download/model.bin", fontSize = 10.sp, color = RockerTextMuted) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = RockerCyanPrimary,
                                        unfocusedBorderColor = RockerBorder,
                                        focusedTextColor = RockerTextPrimary,
                                        unfocusedTextColor = RockerTextSecondary
                                    ),
                                    modifier = Modifier.weight(1f)
                                )

                                OutlinedButton(
                                    onClick = {
                                        val ok = onSetCustomPath(customPathInput)
                                        pathMessage = if (ok) "Path linked!" else "File not found"
                                    }
                                ) {
                                    Text("Link Path", fontSize = 10.sp)
                                }
                            }

                            if (pathMessage != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = pathMessage!!,
                                    color = if (pathMessage!!.contains("linked")) RockerGreenSuccess else RockerRedError,
                                    fontSize = 10.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "DOWNLOAD FROM DIRECT URL (.litertlm / .bin / .task / .gguf)",
                                color = RockerTextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedTextField(
                                    value = customUrlInput,
                                    onValueChange = { customUrlInput = it },
                                    placeholder = { Text("https://example.com/model.litertlm", fontSize = 10.sp, color = RockerTextMuted) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = RockerCyanPrimary,
                                        unfocusedBorderColor = RockerBorder,
                                        focusedTextColor = RockerTextPrimary,
                                        unfocusedTextColor = RockerTextSecondary
                                    ),
                                    modifier = Modifier.weight(1f)
                                )

                                OutlinedButton(
                                    onClick = {
                                        if (customUrlInput.isNotBlank()) {
                                            onDownloadFromUrl(customUrlInput)
                                        }
                                    }
                                ) {
                                    Text("Download", fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Genuine On-Device Inference Benchmark & Diagnostics
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = RockerSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, RockerCyanPrimary.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("diagnostic_inference_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = RockerCyanPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ON-DEVICE INFERENCE BENCHMARK",
                                color = RockerTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = RockerGreenSuccess.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "100% OFFLINE",
                                color = RockerGreenSuccess,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Benchmark real on-device neural token generation, measuring latency, memory footprint, and tokens per second (TPS) on Qualcomm Snapdragon 8s Gen 3 without cloud or API dependencies.",
                        color = RockerTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    ElevatedButton(
                        onClick = onRunDiagnostic,
                        enabled = !isDiagnosticRunning,
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = RockerCyanPrimary,
                            contentColor = RockerBackground
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("run_diagnostic_button")
                    ) {
                        if (isDiagnosticRunning) {
                            CircularProgressIndicator(
                                color = RockerBackground,
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Running On-Device Inference...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Run Diagnostic Inference Test", fontWeight = FontWeight.Bold)
                        }
                    }

                    if (diagnosticResult != null) {
                        val diag = diagnosticResult
                        Spacer(modifier = Modifier.height(12.dp))

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = RockerBackground,
                            border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("diagnostic_result_box")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "EXECUTION METRICS",
                                        color = RockerCyanPrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = diag.executionBackend,
                                        color = RockerTextMuted,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(text = "SPEED", color = RockerTextMuted, fontSize = 9.sp)
                                        Text(
                                            text = "%.1f TPS".format(diag.tokensPerSecond),
                                            color = RockerGreenSuccess,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Column {
                                        Text(text = "LATENCY", color = RockerTextMuted, fontSize = 9.sp)
                                        Text(
                                            text = "${diag.inferenceDurationMs} ms",
                                            color = RockerTextPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Column {
                                        Text(text = "TOKENS", color = RockerTextMuted, fontSize = 9.sp)
                                        Text(
                                            text = "${diag.promptTokens} / ${diag.generatedTokens}",
                                            color = RockerTextPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Column {
                                        Text(text = "WEIGHTS", color = RockerTextMuted, fontSize = 9.sp)
                                        Text(
                                            text = if (diag.isLocalWeightsLoaded) "On-Disk" else "In-Memory",
                                            color = if (diag.isLocalWeightsLoaded) RockerGreenSuccess else RockerAmberWarning,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "OUTPUT GENERATION:",
                                    color = RockerTextMuted,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = diag.generatedResponse,
                                    color = RockerTextSecondary,
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Available On-Device Models Selection
        if (availableModels.isNotEmpty()) {
            item {
                Text(
                    text = "SELECT ON-DEVICE AGENT BRAIN",
                    color = RockerTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            items(availableModels.size) { idx ->
                val m = availableModels[idx]
                val isSelected = m.id == modelState.selectedModelId

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) RockerCyanPrimary.copy(alpha = 0.08f) else RockerSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) RockerCyanPrimary else RockerBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("model_choice_${m.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = m.name,
                                    color = RockerTextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${m.parameters} • ${m.variant} • ${m.requiredStorageMb}MB",
                                    color = RockerCyanPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            if (isSelected) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = RockerGreenSuccess.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "ACTIVE",
                                        color = RockerGreenSuccess,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            } else {
                                OutlinedButton(
                                    onClick = { onSelectModel(m.id) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RockerCyanPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("SELECT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = m.description,
                            color = RockerTextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            m.capabilities.take(3).forEach { cap ->
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = RockerSurfaceVariant
                                ) {
                                    Text(
                                        text = cap,
                                        color = RockerTextMuted,
                                        fontSize = 9.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(14.dp))
            }
        }

        // Hardware Acceleration Specs
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = RockerSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SUPPORTED INFERENCE ACCELERATORS",
                        color = RockerTextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    modelInfo.supportedBackends.forEach { backend ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = RockerGreenSuccess,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = backend, color = RockerTextPrimary, fontSize = 13.sp)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
