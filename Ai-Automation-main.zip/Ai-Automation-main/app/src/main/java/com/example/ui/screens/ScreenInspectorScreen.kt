package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.ScreenUnderstandingEngine
import com.example.model.ScreenSnapshot
import com.example.model.UiElement
import com.example.model.UiRole
import com.example.ui.theme.RockerAmberWarning
import com.example.ui.theme.RockerBackground
import com.example.ui.theme.RockerBorder
import com.example.ui.theme.RockerCyanPrimary
import com.example.ui.theme.RockerGreenSuccess
import com.example.ui.theme.RockerSurface
import com.example.ui.theme.RockerSurfaceVariant
import com.example.ui.theme.RockerTextMuted
import com.example.ui.theme.RockerTextPrimary
import com.example.ui.theme.RockerTextSecondary
import com.example.ui.theme.RockerVioletSecondary

@Composable
fun ScreenInspectorScreen(
    snapshot: ScreenSnapshot?,
    isAccessibilityConnected: Boolean,
    onTestClickElement: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val screenEngine = remember { ScreenUnderstandingEngine() }
    var selectedSandboxAppIndex by remember { mutableIntStateOf(0) }
    val sandboxApps = listOf("YouTube", "Calculator", "Camera", "Clock", "Notes", "WhatsApp", "Chrome", "Settings")

    var simulatedState by remember { mutableStateOf("HOME") }

    val activeSnapshot = remember(selectedSandboxAppIndex, simulatedState, snapshot, isAccessibilityConnected) {
        if (isAccessibilityConnected && snapshot != null && snapshot.elements.isNotEmpty()) {
            snapshot
        } else {
            val app = sandboxApps[selectedSandboxAppIndex]
            screenEngine.generateSandboxSnapshot(app, simulatedState)
        }
    }

    val comprehension = remember(activeSnapshot) {
        screenEngine.analyzeScreen(activeSnapshot)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RockerBackground)
            .padding(16.dp)
    ) {
        // Mode Header Card
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = RockerSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (isAccessibilityConnected) RockerGreenSuccess else RockerAmberWarning)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isAccessibilityConnected) "LIVE ACCESSIBILITY SERVICE ACTIVE" else "AUTONOMOUS SANDBOX SIMULATOR",
                                color = if (isAccessibilityConnected) RockerGreenSuccess else RockerCyanPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = "${activeSnapshot.elements.size} Nodes",
                            color = RockerTextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Active Target: ${activeSnapshot.packageName}",
                        color = RockerTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = comprehension.descriptionSummary,
                        color = RockerTextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Sandbox App Selector (if running in emulator or simulator)
        if (!isAccessibilityConnected) {
            item {
                Text(
                    text = "SELECT APPLICATION SANDBOX TO INSPECT",
                    color = RockerTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))

                ScrollableTabRow(
                    selectedTabIndex = selectedSandboxAppIndex,
                    edgePadding = 0.dp,
                    containerColor = RockerSurface,
                    contentColor = RockerCyanPrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.Indicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSandboxAppIndex]),
                            color = RockerCyanPrimary
                        )
                    }
                ) {
                    sandboxApps.forEachIndexed { index, app ->
                        Tab(
                            selected = selectedSandboxAppIndex == index,
                            onClick = {
                                selectedSandboxAppIndex = index
                                simulatedState = "HOME"
                            },
                            text = { Text(app, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // State switcher chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val states = listOf("HOME", "ACCOUNT_PROMPT", "AD_POPUP", "SEARCH_RESULTS", "SITE_OPENED")
                    states.forEach { st ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (simulatedState == st) RockerCyanPrimary.copy(alpha = 0.2f) else RockerSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (simulatedState == st) RockerCyanPrimary else RockerBorder
                            ),
                            modifier = Modifier
                                .clickable { simulatedState = st }
                                .padding(vertical = 2.dp)
                        ) {
                            Text(
                                text = st,
                                color = if (simulatedState == st) RockerCyanPrimary else RockerTextMuted,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }
        }

        // Obstacle Detection Alert Banner
        if (comprehension.detectedObstacle != null) {
            val obs = comprehension.detectedObstacle
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = RockerAmberWarning.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RockerAmberWarning),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SCREEN OBSTACLE DETECTED: ${obs.title.uppercase()}",
                                color = RockerAmberWarning,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Auto-dismiss action: '${obs.dismissLabel}' (Element ID: ${obs.dismissElementId})",
                                color = RockerTextPrimary,
                                fontSize = 11.sp
                            )
                        }

                        OutlinedButton(
                            onClick = { onTestClickElement(obs.dismissElementId) },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = RockerAmberWarning),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("TEST BYPASS", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Semantic Role Summary Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RoleStatChip("Search Bars", if (comprehension.searchBarElement != null) 1 else 0, RockerCyanPrimary)
                RoleStatChip("Input Fields", comprehension.inputFields.size, RockerVioletSecondary)
                RoleStatChip("Items/Cards", comprehension.listItems.size, RockerAmberWarning)
                RoleStatChip("Clickables", activeSnapshot.clickableElements.size, RockerGreenSuccess)
            }
        }

        // Section Title: Elements
        item {
            Text(
                text = "DETECTED UI HIERARCHY NODES",
                color = RockerTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }

        // Element List
        items(activeSnapshot.elements) { el ->
            UiElementCard(element = el, onTestClick = { onTestClickElement(el.id) })
            Spacer(modifier = Modifier.height(6.dp))
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun RoleStatChip(label: String, count: Int, color: Color) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = RockerSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text(text = "$count", color = color, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(text = label, color = RockerTextMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun UiElementCard(element: UiElement, onTestClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = RockerSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, RockerSurfaceVariant),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("element_node_${element.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = getRoleColor(element.role).copy(alpha = 0.15f)
                ) {
                    Text(
                        text = element.role.name,
                        color = getRoleColor(element.role),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = "[${element.boundsLeft}, ${element.boundsTop} - ${element.boundsRight}, ${element.boundsBottom}]",
                    color = RockerTextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = element.displayLabel,
                color = RockerTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )

            if (element.viewIdResourceName != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "ID: ${element.viewIdResourceName}",
                    color = RockerTextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (element.isClickable) PropertyBadge("clickable", RockerGreenSuccess)
                    if (element.isEditable) PropertyBadge("editable", RockerCyanPrimary)
                    if (element.isScrollable) PropertyBadge("scrollable", RockerVioletSecondary)
                }

                if (element.isClickable) {
                    Text(
                        text = "TEST TAP",
                        color = RockerCyanPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { onTestClick() }
                            .padding(4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PropertyBadge(label: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = color.copy(alpha = 0.1f)
    ) {
        Text(
            text = label,
            color = color,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
    }
}

private fun getRoleColor(role: UiRole): Color {
    return when (role) {
        UiRole.SEARCH_BAR -> RockerCyanPrimary
        UiRole.INPUT_FIELD -> RockerVioletSecondary
        UiRole.BUTTON -> RockerGreenSuccess
        UiRole.LIST_ITEM -> RockerAmberWarning
        UiRole.TITLE -> RockerTextPrimary
        else -> RockerTextMuted
    }
}
