package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Rocker AI Cybernetic Dark Palette
val RockerBackground = Color(0xFF090D16)
val RockerSurface = Color(0xFF101726)
val RockerSurfaceVariant = Color(0xFF18233A)
val RockerBorder = Color(0xFF263554)

val RockerCyanPrimary = Color(0xFF00E5FF)
val RockerCyanOnPrimary = Color(0xFF002029)
val RockerCyanContainer = Color(0xFF004D5A)

val RockerVioletSecondary = Color(0xFF9D65FF)
val RockerVioletContainer = Color(0xFF371E68)

val RockerGreenSuccess = Color(0xFF00E676)
val RockerRedError = Color(0xFFFF5252)
val RockerAmberWarning = Color(0xFFFFB300)

val RockerTextPrimary = Color(0xFFF1F5F9)
val RockerTextSecondary = Color(0xFF94A3B8)
val RockerTextMuted = Color(0xFF64748B)

val OrbListeningGlow = Color(0xFF00E5FF)
val OrbReasoningGlow = Color(0xFFB388FF)
val OrbExecutingGlow = Color(0xFF00E676)
val OrbIdleGlow = Color(0xFF475569)
