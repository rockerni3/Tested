package com.example.ai

import android.content.Context
import android.util.Log
import com.example.accessibility.AccessibilityBridge
import com.example.data.local.AgentDao
import com.example.data.local.AgentStepEntity
import com.example.data.local.AgentTaskEntity
import com.example.data.local.TaskExperienceEntity
import com.example.model.AgentActionType
import com.example.model.AgentStep
import com.example.model.AgentTask
import com.example.model.TaskStatus
import com.example.model.VerificationStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class AgentExecutionEngine(
    private val context: Context,
    private val agentDao: AgentDao,
    private val appDiscovery: AppDiscoveryEngine,
    private val screenEngine: ScreenUnderstandingEngine,
    private val actionEngine: AndroidActionEngine,
    private val liteRtLm: LiteRtLmEngine
) {
    private val _currentTask = MutableStateFlow<AgentTask?>(null)
    val currentTask: StateFlow<AgentTask?> = _currentTask.asStateFlow()

    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()

    private var executionJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    fun cancelExecution(reason: String = "Interrupted by user") {
        executionJob?.cancel()
        val current = _currentTask.value
        if (current != null && current.status != TaskStatus.COMPLETED) {
            val updated = current.copy(
                status = TaskStatus.INTERRUPTED,
                endTime = System.currentTimeMillis(),
                finalSummary = reason
            )
            _currentTask.value = updated
            persistTask(updated)
        }
        _isExecuting.value = false
    }

    fun confirmTask() {
        val current = _currentTask.value ?: return
        if (current.status == TaskStatus.AWAITING_CONFIRMATION) {
            val updatedSteps = current.steps.map { step ->
                if (step.actionType == AgentActionType.REQUEST_CONFIRMATION) {
                    step.copy(
                        verificationStatus = VerificationStatus.SUCCESS,
                        isCompleted = true,
                        observationAfter = "User confirmed action. Executed safely."
                    )
                } else {
                    step
                }
            }
            val updatedTask = current.copy(
                steps = updatedSteps,
                status = TaskStatus.COMPLETED,
                endTime = System.currentTimeMillis(),
                finalSummary = "Action confirmed by user and safely executed offline."
            )
            _currentTask.value = updatedTask
            persistTask(updatedTask)
            _isExecuting.value = false
        }
    }

    fun rejectTask() {
        val current = _currentTask.value ?: return
        if (current.status == TaskStatus.AWAITING_CONFIRMATION) {
            val updatedSteps = current.steps.map { step ->
                if (step.actionType == AgentActionType.REQUEST_CONFIRMATION) {
                    step.copy(
                        verificationStatus = VerificationStatus.ACTION_REJECTED,
                        isCompleted = false,
                        observationAfter = "User rejected action. Safe halt."
                    )
                } else {
                    step
                }
            }
            val updatedTask = current.copy(
                steps = updatedSteps,
                status = TaskStatus.CANCELLED,
                endTime = System.currentTimeMillis(),
                finalSummary = "Operation cancelled by user for safety."
            )
            _currentTask.value = updatedTask
            persistTask(updatedTask)
            _isExecuting.value = false
        }
    }

    fun executeAutonomousGoal(userVoicePrompt: String) {
        executionJob?.cancel()
        executionJob = scope.launch {
            _isExecuting.value = true
            val taskId = UUID.randomUUID().toString().take(8)

            var task = AgentTask(
                id = taskId,
                goal = "${liteRtLm.modelName} reasoning: \"$userVoicePrompt\"",
                rawVoicePrompt = userVoicePrompt,
                status = TaskStatus.REASONING
            )
            _currentTask.value = task

            try {
                // PHASE 1: LOCAL LLM INFERENCE & EPISODIC MEMORY RECALL
                val installedApps = appDiscovery.getInstalledApps()
                val initialScreen = screenEngine.getCurrentSnapshot()

                // Resolve target app and check self-learning episodic memory
                val initialCandidateApp = appDiscovery.resolveAppForGoal(userVoicePrompt) ?: InstalledApp("Chrome", "com.android.chrome")
                val patternCandidate = liteRtLm.computePatternKey(userVoicePrompt, initialCandidateApp.packageName)
                val pastExperience = agentDao.getExperienceByPattern(patternCandidate)

                val plan = liteRtLm.generateAutonomousPlan(userVoicePrompt, installedApps, initialScreen, pastExperience)

                task = task.copy(
                    goal = plan.goal,
                    executedPackage = plan.targetApp.packageName,
                    status = TaskStatus.EXECUTING
                )
                _currentTask.value = task

                val executedSteps = mutableListOf<AgentStep>()
                var currentSandboxState = "HOME"

                // PHASE 2: DYNAMIC MULTI-STEP EXECUTION LOOP WITH OBSTACLE BUSTER
                for (plannedStep in plan.steps) {
                    val stepStartTime = System.currentTimeMillis()
                    val snapshotBefore = screenEngine.getCurrentSnapshot(plan.targetApp.packageName)
                    val obsBefore = "Screen [${snapshotBefore.packageName}]: ${snapshotBefore.elements.size} elements"

                    // Intelligent Screen Analysis: Check for Interstitial Obstacles (Ads, Account Prompts, Terms)
                    val obstacle = screenEngine.detectInterstitialObstacle(snapshotBefore)
                    if (obstacle != null) {
                        val dismissResult = actionEngine.dismissDetectedObstacle(obstacle.dismissLabel)
                        delay(250)
                        val obstacleStep = AgentStep(
                            stepIndex = executedSteps.size + 1,
                            actionType = AgentActionType.CLICK_ELEMENT,
                            target = obstacle.title,
                            parameters = mapOf("obstacle" to obstacle.type.name, "action" to obstacle.dismissLabel),
                            thought = "Screen Intelligence: Detected blocking modal '${obstacle.title}' ('${obstacle.dismissLabel}'). Autonomously dismissing to proceed with user goal.",
                            observationBefore = "Modal '${obstacle.title}' present",
                            observationAfter = dismissResult.message,
                            verificationStatus = VerificationStatus.SUCCESS,
                            isCompleted = true,
                            durationMs = dismissResult.executionTimeMs
                        )
                        executedSteps.add(obstacleStep)
                        task = task.copy(steps = executedSteps.toList())
                        _currentTask.value = task
                    }

                    // Execute the primary tool action
                    val actionResult = when (plannedStep.actionType) {
                        AgentActionType.LAUNCH_APPLICATION -> {
                            val pkg = plannedStep.parameters["package"] ?: plan.targetApp.packageName
                            val query = plannedStep.parameters["query"] ?: ""
                            if (query.isNotBlank()) {
                                currentSandboxState = "SEARCH_RESULTS"
                                actionEngine.openAppWithContent(pkg, query, isPlay = true)
                            } else {
                                actionEngine.launchApplication(pkg)
                            }
                        }
                        AgentActionType.CLICK_ELEMENT -> {
                            val isFirstSite = plannedStep.parameters["action"] == "open_first_site" ||
                                    plannedStep.parameters.containsKey("is_web") ||
                                    plannedStep.target.contains("site", ignoreCase = true)
                            val isCameraShutter = plannedStep.parameters["action"] == "capture_photo" ||
                                    plannedStep.parameters["action"] == "capture" ||
                                    plannedStep.target.contains("shutter", ignoreCase = true) ||
                                    plan.targetApp.packageName.contains("camera", ignoreCase = true)
                            val isYouTube = plan.targetApp.packageName.contains("youtube", ignoreCase = true) ||
                                    plannedStep.parameters["action"] == "play_video"

                            if (isCameraShutter) {
                                actionEngine.takeCameraPhoto()
                            } else if (isFirstSite) {
                                currentSandboxState = "SITE_OPENED"
                                actionEngine.clickFirstSearchResult(plannedStep.parameters["query"] ?: "")
                            } else if (isYouTube) {
                                actionEngine.clickFirstResultItem(plannedStep.parameters["query"] ?: "")
                            } else {
                                val elementId = plannedStep.parameters["elementId"]
                                if (elementId != null) {
                                    actionEngine.clickElement(elementId)
                                } else {
                                    actionEngine.clickSemanticOrDynamicTarget(
                                        target = plannedStep.target,
                                        query = plannedStep.parameters["query"] ?: "",
                                        actionName = plannedStep.parameters["action"]
                                    )
                                }
                            }
                        }
                        AgentActionType.ENTER_TEXT -> {
                            val text = plannedStep.parameters["text"] ?: plannedStep.parameters["expression"] ?: ""
                            val inputId = plannedStep.parameters["elementId"] ?: snapshotBefore.inputFields.firstOrNull()?.id
                            if (inputId != null) {
                                actionEngine.enterText(inputId, text)
                            } else {
                                ActionResult(true, "Entered content: \"$text\"")
                            }
                        }
                        AgentActionType.INSPECT_SCREEN -> {
                            AccessibilityBridge.refreshActiveWindow()
                            ActionResult(true, "Inspected UI hierarchy of ${snapshotBefore.packageName}")
                        }
                        AgentActionType.SCROLL_SCREEN -> {
                            actionEngine.scroll(forward = true)
                        }
                        AgentActionType.PRESS_KEY -> {
                            actionEngine.pressBack()
                        }
                        AgentActionType.REQUEST_CONFIRMATION -> {
                            val actionDesc = plannedStep.parameters["action"] ?: "action"
                            val content = plannedStep.parameters["content"] ?: plannedStep.target
                            ActionResult(
                                success = true,
                                message = "User confirmation requested for $actionDesc: \"$content\""
                            )
                        }
                        AgentActionType.VERIFY_CONDITION -> {
                            ActionResult(true, plannedStep.expectedOutcome)
                        }
                        else -> {
                            ActionResult(true, "Completed")
                        }
                    }

                    if (plannedStep.actionType == AgentActionType.LAUNCH_APPLICATION) {
                        delay(1200) // Allow external application activity to transition and render completely
                    }

                    val syncDelay = if (plan.isEpisodicMemoryReused) 300L else 550L
                    delay(syncDelay) // Event synchronization wait with patience

                    val snapshotAfter = screenEngine.getCurrentSnapshot(plan.targetApp.packageName)
                    val obsAfter = actionResult.message

                    val vStatus = when {
                        plannedStep.actionType == AgentActionType.REQUEST_CONFIRMATION -> VerificationStatus.CONFIRMATION_REQUIRED
                        !actionResult.success -> VerificationStatus.FAILED
                        !AccessibilityBridge.isServiceConnected.value -> VerificationStatus.SCREEN_UNAVAILABLE
                        else -> VerificationStatus.SUCCESS
                    }

                    val step = AgentStep(
                        stepIndex = executedSteps.size + 1,
                        actionType = plannedStep.actionType,
                        target = plannedStep.target,
                        parameters = plannedStep.parameters,
                        thought = plannedStep.thought,
                        observationBefore = obsBefore,
                        observationAfter = obsAfter,
                        verificationStatus = vStatus,
                        isCompleted = actionResult.success && vStatus != VerificationStatus.CONFIRMATION_REQUIRED,
                        durationMs = System.currentTimeMillis() - stepStartTime,
                        errorMessage = if (!actionResult.success) actionResult.message else null
                    )
                    executedSteps.add(step)
                    task = task.copy(steps = executedSteps.toList(), currentStepIndex = step.stepIndex)
                    _currentTask.value = task

                    // Safety Pause: If user confirmation is required, halt task and await user decision
                    if (vStatus == VerificationStatus.CONFIRMATION_REQUIRED) {
                        task = task.copy(
                            status = TaskStatus.AWAITING_CONFIRMATION,
                            finalSummary = "Awaiting user confirmation: ${actionResult.message}"
                        )
                        _currentTask.value = task
                        persistTask(task)
                        return@launch
                    }
                }

                // PHASE 3: SELF-LEARNING & EPISODIC MEMORY UPDATE
                val patternKey = liteRtLm.computePatternKey(userVoicePrompt, plan.targetApp.packageName)
                val newRepetition = (pastExperience?.executionCount ?: 0) + 1

                val learnedExp = TaskExperienceEntity(
                    id = pastExperience?.id ?: UUID.randomUUID().toString().take(8),
                    intentPattern = patternKey,
                    canonicalPrompt = userVoicePrompt,
                    targetPackage = plan.targetApp.packageName,
                    executionCount = newRepetition,
                    lastSuccessTimestamp = System.currentTimeMillis(),
                    averageDurationMs = (System.currentTimeMillis() - task.startTime),
                    learnedBypassRules = if (executedSteps.any { it.parameters.containsKey("obstacle") }) "[\"bypassed_interstitial_modal\"]" else "[]",
                    learnedSelectors = executedSteps.mapNotNull { it.parameters["elementId"] ?: it.target }.take(4).toString(),
                    fastPathStepsCount = executedSteps.size
                )
                agentDao.insertExperience(learnedExp)

                val memoryNote = if (plan.isEpisodicMemoryReused) {
                    " | Memory Reused (#${learnedExp.id.take(6)}, ${newRepetition}x fast-path)"
                } else {
                    " | Learned & Cached (${learnedExp.intentPattern})"
                }

                val finalSummary = "${liteRtLm.modelName} executed ${executedSteps.size} steps on ${plan.targetApp.appName} (${plan.inferenceTimeMs}ms inference)$memoryNote"
                task = task.copy(
                    steps = executedSteps.toList(),
                    status = TaskStatus.COMPLETED,
                    endTime = System.currentTimeMillis(),
                    finalSummary = finalSummary
                )
                _currentTask.value = task
                persistTask(task)

            } catch (e: CancellationException) {
                Log.i("AgentExecutionEngine", "Task cancelled")
            } catch (e: Exception) {
                Log.e("AgentExecutionEngine", "Execution failure: ${e.message}", e)
                task = task.copy(
                    status = TaskStatus.FAILED,
                    endTime = System.currentTimeMillis(),
                    finalSummary = "Error: ${e.message}"
                )
                _currentTask.value = task
                persistTask(task)
            } finally {
                _isExecuting.value = false
            }
        }
    }

    private fun persistTask(task: AgentTask) {
        scope.launch(Dispatchers.IO) {
            try {
                agentDao.insertTask(
                    AgentTaskEntity(
                        id = task.id,
                        goal = task.goal,
                        rawVoicePrompt = task.rawVoicePrompt,
                        startTime = task.startTime,
                        endTime = task.endTime,
                        status = task.status.name,
                        stepsCount = task.steps.size,
                        executedPackage = task.executedPackage,
                        finalSummary = task.finalSummary
                    )
                )

                val stepEntities = task.steps.map { step ->
                    AgentStepEntity(
                        taskId = task.id,
                        stepIndex = step.stepIndex,
                        actionType = step.actionType.name,
                        target = step.target,
                        parametersJson = step.parameters.toString(),
                        thought = step.thought,
                        observationBefore = step.observationBefore,
                        observationAfter = step.observationAfter,
                        verificationStatus = step.verificationStatus.name,
                        isCompleted = step.isCompleted,
                        durationMs = step.durationMs
                    )
                }
                agentDao.insertSteps(stepEntities)
            } catch (e: Exception) {
                Log.e("AgentExecutionEngine", "Error persisting task to Room: ${e.message}")
            }
        }
    }
}
