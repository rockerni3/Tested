package com.example.ai

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledApp(
    val appName: String,
    val packageName: String,
    val launchActivity: String? = null,
    val icon: Drawable? = null,
    val isSystemApp: Boolean = false
)

class AppDiscoveryEngine(private val context: Context) {

    private var cachedApps: List<InstalledApp> = emptyList()

    suspend fun getInstalledApps(forceRefresh: Boolean = false): List<InstalledApp> = withContext(Dispatchers.IO) {
        if (cachedApps.isNotEmpty() && !forceRefresh) return@withContext cachedApps

        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = try {
            pm.queryIntentActivities(intent, 0)
        } catch (e: Exception) {
            emptyList()
        }

        val apps = resolveInfos.mapNotNull { resolveInfo ->
            val pkg = resolveInfo.activityInfo.packageName
            val label = resolveInfo.loadLabel(pm).toString()
            val isSystem = (resolveInfo.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            InstalledApp(
                appName = label,
                packageName = pkg,
                launchActivity = resolveInfo.activityInfo.name,
                isSystemApp = isSystem
            )
        }.distinctBy { it.packageName }

        // Comprehensive standard Android application roster for full coverage across all domains
        val standardApps = listOf(
            InstalledApp("YouTube", "com.google.android.youtube"),
            InstalledApp("WhatsApp", "com.whatsapp"),
            InstalledApp("Calculator", "com.google.android.calculator"),
            InstalledApp("Camera", "com.android.camera"),
            InstalledApp("Clock", "com.google.android.deskclock"),
            InstalledApp("Chrome", "com.android.chrome"),
            InstalledApp("Settings", "com.android.settings"),
            InstalledApp("Messages", "com.google.android.apps.messaging"),
            InstalledApp("Spotify", "com.spotify.music"),
            InstalledApp("Google Maps", "com.google.android.apps.maps"),
            InstalledApp("Notes", "com.google.android.keep"),
            InstalledApp("Photos", "com.google.android.apps.photos"),
            InstalledApp("Phone", "com.google.android.dialer"),
            InstalledApp("Contacts", "com.google.android.contacts"),
            InstalledApp("Files", "com.google.android.apps.nbu.files"),
            InstalledApp("Instagram", "com.instagram.android"),
            InstalledApp("Telegram", "org.telegram.messenger")
        )

        val merged = (apps + standardApps).distinctBy { it.packageName.lowercase() }
        cachedApps = merged
        merged
    }

    suspend fun resolveAppForGoal(goalOrTarget: String): InstalledApp? {
        val apps = getInstalledApps()
        val query = goalOrTarget.lowercase().trim()

        // 1. Direct exact or substring match on appName
        apps.firstOrNull { it.appName.lowercase() == query }?.let { return it }
        apps.firstOrNull { query == it.appName.lowercase() || query.contains(it.appName.lowercase()) }?.let { return it }
        apps.firstOrNull { it.appName.lowercase().contains(query) }?.let { return it }

        // 2. Query words contained in app name or package name (e.g. "rocker", "workout")
        val queryWords = query.split(" ", "_", "-").filter { it.length > 2 && !it.equals("the", true) && !it.equals("app", true) && !it.equals("open", true) && !it.equals("there", true) && !it.equals("add", true) }
        for (word in queryWords) {
            apps.firstOrNull { it.appName.lowercase().contains(word) || it.packageName.lowercase().contains(word) }?.let { return it }
        }

        // 3. Semantic category mapping
        when {
            query.contains("calc") || query.contains("math") || query.contains("add") || query.contains("multiply") -> {
                return apps.firstOrNull { it.packageName.contains("calc") || it.appName.contains("calc", true) }
            }
            query.contains("camera") || query.contains("photo") || query.contains("picture") || query.contains("selfie") -> {
                return apps.firstOrNull { it.packageName.contains("camera") || it.appName.contains("camera", true) }
            }
            query.contains("clock") || query.contains("alarm") || query.contains("timer") || query.contains("stopwatch") -> {
                return apps.firstOrNull { it.packageName.contains("clock") || it.appName.contains("clock", true) }
            }
            query.contains("map") || query.contains("navigate") || query.contains("gps") || query.contains("directions") -> {
                return apps.firstOrNull { it.packageName.contains("maps") || it.appName.contains("maps", true) }
            }
            query.contains("note") || query.contains("memo") || query.contains("todo") || query.contains("keep") -> {
                return apps.firstOrNull { it.packageName.contains("keep") || it.appName.contains("note", true) }
            }
            query.contains("spotify") || query.contains("music") || query.contains("audio") -> {
                return apps.firstOrNull { it.packageName.contains("spotify") }
                    ?: apps.firstOrNull { it.appName.contains("Music", true) }
            }
            query.contains("youtube") || query.contains("video") || query.contains("stream") -> {
                return apps.firstOrNull { it.packageName.contains("youtube") || it.appName.contains("YouTube", true) }
            }
            query.contains("whatsapp") || query.contains("message") || query.contains("chat") || query.contains("sms") -> {
                return if (query.contains("whatsapp")) {
                    apps.firstOrNull { it.packageName.contains("whatsapp") }
                } else {
                    apps.firstOrNull { it.appName.contains("Message", true) }
                        ?: apps.firstOrNull { it.packageName.contains("whatsapp") }
                }
            }
            query.contains("browse") || query.contains("web") || query.contains("search") || query.contains("chrome") -> {
                return apps.firstOrNull { it.packageName.contains("chrome") }
                    ?: apps.firstOrNull { it.appName.contains("Browser", true) }
            }
            query.contains("setting") || query.contains("wifi") || query.contains("bluetooth") || query.contains("battery") -> {
                return apps.firstOrNull { it.packageName.contains("settings") }
            }
            query.contains("gallery") || query.contains("album") -> {
                return apps.firstOrNull { it.packageName.contains("photos") || it.appName.contains("photo", true) || it.appName.contains("gallery", true) }
            }
            query.contains("call") || query.contains("dial") || query.contains("phone") -> {
                return apps.firstOrNull { it.packageName.contains("dialer") || it.appName.contains("phone", true) }
            }
        }

        return apps.firstOrNull { query.contains(it.appName.lowercase()) }
    }
}
