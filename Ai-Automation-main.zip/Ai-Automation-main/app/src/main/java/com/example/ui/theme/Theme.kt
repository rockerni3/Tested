package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val RockerColorScheme = darkColorScheme(
    primary = RockerCyanPrimary,
    onPrimary = RockerCyanOnPrimary,
    primaryContainer = RockerCyanContainer,
    onPrimaryContainer = RockerCyanPrimary,
    secondary = RockerVioletSecondary,
    onSecondary = RockerBackground,
    secondaryContainer = RockerVioletContainer,
    onSecondaryContainer = RockerTextPrimary,
    background = RockerBackground,
    onBackground = RockerTextPrimary,
    surface = RockerSurface,
    onSurface = RockerTextPrimary,
    surfaceVariant = RockerSurfaceVariant,
    onSurfaceVariant = RockerTextSecondary,
    outline = RockerBorder,
    error = RockerRedError,
    onError = RockerBackground
)

@Composable
fun RockerTheme(
    darkTheme: Boolean = true, // Rocker AI is built with an immersive cybernetic dark aesthetic
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RockerColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    RockerTheme(darkTheme = true, content = content)
}
