package com.example.ai

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import com.example.accessibility.AccessibilityBridge
import java.net.URLEncoder

data class ActionResult(
    val success: Boolean,
    val message: String,
    val executionTimeMs: Long = 0L
)

class AndroidActionEngine(private val context: Context) {

    fun launchApplication(packageName: String): ActionResult {
        val start = System.currentTimeMillis()
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                ActionResult(true, "Launched package: $packageName", System.currentTimeMillis() - start)
            } else {
                // If package not installed, try general resolution or store view
                val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(marketIntent)
                    ActionResult(true, "Redirected to application package: $packageName", System.currentTimeMillis() - start)
                } catch (_: Exception) {
                    ActionResult(false, "App package $packageName not available on device", System.currentTimeMillis() - start)
                }
            }
        } catch (e: Exception) {
            ActionResult(false, "Failed to launch $packageName: ${e.message}", System.currentTimeMillis() - start)
        }
    }

    fun openAppWithContent(packageName: String, query: String, isPlay: Boolean = false): ActionResult {
        val start = System.currentTimeMillis()
        val lowerPkg = packageName.lowercase()
        val cleanQuery = query.trim()

        return try {
            when {
                lowerPkg.contains("camera") -> {
                    val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(intent)
                        ActionResult(true, "Opened Camera in photo capture mode", System.currentTimeMillis() - start)
                    } catch (_: Exception) {
                        launchApplication(packageName)
                    }
                }
                lowerPkg.contains("calc") -> {
                    launchApplication(packageName)
                }
                lowerPkg.contains("clock") || lowerPkg.contains("deskclock") -> {
                    if (cleanQuery.isNotBlank() && (cleanQuery.contains("am", true) || cleanQuery.contains("pm", true) || cleanQuery.contains(":"))) {
                        val alarmIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                            putExtra(AlarmClock.EXTRA_MESSAGE, "Rocker AI Alarm")
                            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        try {
                            context.startActivity(alarmIntent)
                            ActionResult(true, "Opened Clock to set alarm for $cleanQuery", System.currentTimeMillis() - start)
                        } catch (_: Exception) {
                            launchApplication(packageName)
                        }
                    } else {
                        launchApplication(packageName)
                    }
                }
                lowerPkg.contains("maps") -> {
                    val uri = if (cleanQuery.isNotBlank()) {
                        Uri.parse("geo:0,0?q=" + URLEncoder.encode(cleanQuery, "UTF-8"))
                    } else {
                        Uri.parse("geo:0,0")
                    }
                    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                        setPackage("com.google.android.apps.maps")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(intent)
                        ActionResult(true, "Opened Google Maps for \"$cleanQuery\"", System.currentTimeMillis() - start)
                    } catch (_: Exception) {
                        launchApplication(packageName)
                    }
                }
                lowerPkg.contains("youtube") -> {
                    val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
                    val ytUri = Uri.parse("https://www.youtube.com/results?search_query=$encoded")
                    val intent = Intent(Intent.ACTION_VIEW, ytUri).apply {
                        setPackage("com.google.android.youtube")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }

                    try {
                        context.startActivity(intent)
                        ActionResult(true, "Opened YouTube with search results for \"$cleanQuery\"", System.currentTimeMillis() - start)
                    } catch (_: Exception) {
                        val fallback = Intent(Intent.ACTION_VIEW, ytUri).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(fallback)
                        ActionResult(true, "Opened YouTube search in browser for \"$cleanQuery\"", System.currentTimeMillis() - start)
                    }
                }
                lowerPkg.contains("whatsapp") -> {
                    val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
                    val waUri = Uri.parse("https://api.whatsapp.com/send?text=$encoded")
                    val intent = Intent(Intent.ACTION_VIEW, waUri).apply {
                        setPackage("com.whatsapp")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(intent)
                        ActionResult(true, "Opened WhatsApp draft with message", System.currentTimeMillis() - start)
                    } catch (_: Exception) {
                        launchApplication(packageName)
                    }
                }
                lowerPkg.contains("chrome") || lowerPkg.contains("browser") -> {
                    val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
                    val searchUri = Uri.parse("https://www.google.com/search?q=$encoded")
                    val intent = Intent(Intent.ACTION_VIEW, searchUri).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    ActionResult(true, "Executed web search for \"$cleanQuery\"", System.currentTimeMillis() - start)
                }
                lowerPkg.contains("spotify") -> {
                    val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:$encoded")).apply {
                        setPackage("com.spotify.music")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(intent)
                        ActionResult(true, "Opened Spotify search for \"$cleanQuery\"", System.currentTimeMillis() - start)
                    } catch (_: Exception) {
                        launchApplication(packageName)
                    }
                }
                lowerPkg.contains("settings") -> {
                    val action = when {
                        cleanQuery.contains("wifi", true) || cleanQuery.contains("internet", true) -> Settings.ACTION_WIFI_SETTINGS
                        cleanQuery.contains("bluetooth", true) -> Settings.ACTION_BLUETOOTH_SETTINGS
                        cleanQuery.contains("battery", true) -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                        cleanQuery.contains("app", true) -> Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS
                        cleanQuery.contains("display", true) -> Settings.ACTION_DISPLAY_SETTINGS
                        else -> Settings.ACTION_SETTINGS
                    }
                    val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                    context.startActivity(intent)
                    ActionResult(true, "Opened system settings for $cleanQuery", System.currentTimeMillis() - start)
                }
                else -> {
                    launchApplication(packageName)
                }
            }
        } catch (e: Exception) {
            ActionResult(false, "Failed to dispatch action: ${e.message}", System.currentTimeMillis() - start)
        }
    }

    fun clickElement(elementId: String): ActionResult {
        val start = System.currentTimeMillis()
        val success = AccessibilityBridge.clickElement(elementId)
        return ActionResult(
            success = success,
            message = if (success) "Clicked element $elementId" else "Element not found or not clickable in active window",
            executionTimeMs = System.currentTimeMillis() - start
        )
    }

    suspend fun takeCameraPhoto(): ActionResult {
        val start = System.currentTimeMillis()
        if (!AccessibilityBridge.isServiceConnected.value) {
            return ActionResult(false, "Accessibility Service is not enabled. Please enable Rocker in Settings > Accessibility.", System.currentTimeMillis() - start)
        }

        // Patience: Wait for camera viewfinder and shutter button to stabilize
        for (attempt in 1..8) {
            AccessibilityBridge.refreshActiveWindow()
            val clicked = AccessibilityBridge.findAndClickCameraShutter()
            if (clicked) {
                kotlinx.coroutines.delay(650) // Allow camera sensor exposure and disk writing
                return ActionResult(true, "Triggered camera shutter and captured photo successfully", System.currentTimeMillis() - start)
            }
            kotlinx.coroutines.delay(350)
        }
        return ActionResult(false, "Camera shutter button could not be triggered in active window", System.currentTimeMillis() - start)
    }

    suspend fun clickSemanticOrDynamicTarget(
        target: String,
        query: String = "",
        actionName: String? = null
    ): ActionResult {
        val start = System.currentTimeMillis()
        if (!AccessibilityBridge.isServiceConnected.value) {
            return ActionResult(false, "Accessibility Service is not enabled.", System.currentTimeMillis() - start)
        }

        val keywords = mutableListOf<String>()
        if (target.isNotBlank()) keywords.add(target)
        if (query.isNotBlank()) keywords.add(query)
        val queryWords = query.split(" ", "_", "-").filter { it.length > 2 }
        keywords.addAll(queryWords)
        keywords.addAll(listOf("add", "plan", "routine", "workout", "new", "create", "+"))

        // Patience loop: check screen, auto-dismiss obstacles, inspect drawer, and scroll if needed
        for (attempt in 1..6) {
            AccessibilityBridge.refreshActiveWindow()

            // 1. Auto-dismiss any unexpected popups or interstitial modals
            val obstacle = AccessibilityBridge.findObstacleDismissNode()
            if (obstacle != null) {
                AccessibilityBridge.clickNode(obstacle)
                kotlinx.coroutines.delay(400)
                continue
            }

            // 2. Direct semantic match on active screen
            val match = AccessibilityBridge.findSemanticElement(keywords)
            if (match != null) {
                val clicked = AccessibilityBridge.clickNode(match)
                val label = (match.text ?: match.contentDescription ?: target).toString().take(50)
                if (clicked) {
                    return ActionResult(true, "Identified and clicked \"$label\"", System.currentTimeMillis() - start)
                }
            }

            // 3. Check for hamburger navigation icon to explore sidebar drawer
            if (attempt == 2) {
                val drawer = AccessibilityBridge.findHamburgerMenuNode()
                if (drawer != null) {
                    AccessibilityBridge.clickNode(drawer)
                    kotlinx.coroutines.delay(500)
                    AccessibilityBridge.refreshActiveWindow()
                    val drawerMatch = AccessibilityBridge.findSemanticElement(keywords)
                    if (drawerMatch != null && AccessibilityBridge.clickNode(drawerMatch)) {
                        val label = (drawerMatch.text ?: drawerMatch.contentDescription ?: target).toString().take(50)
                        return ActionResult(true, "Opened navigation drawer and clicked \"$label\"", System.currentTimeMillis() - start)
                    }
                }
            }

            // 4. Scroll down to reveal content below the fold
            if (attempt in 3..4) {
                AccessibilityBridge.scroll(true)
                kotlinx.coroutines.delay(450)
            } else {
                kotlinx.coroutines.delay(350)
            }
        }

        return ActionResult(false, "Could not locate target \"$target\" on screen", System.currentTimeMillis() - start)
    }

    suspend fun clickFirstResultItem(query: String = ""): ActionResult {
        val start = System.currentTimeMillis()
        if (!AccessibilityBridge.isServiceConnected.value) {
            return ActionResult(
                success = false,
                message = "Accessibility Service is not enabled. Please enable Rocker in Settings > Accessibility.",
                executionTimeMs = System.currentTimeMillis() - start
            )
        }

        // Poll up to 10 attempts (3.5 seconds) for YouTube video results to populate
        for (attempt in 1..10) {
            AccessibilityBridge.refreshActiveWindow()

            // Check & clear any popup/ad modals first
            val obstacle = AccessibilityBridge.findObstacleDismissNode()
            if (obstacle != null) {
                AccessibilityBridge.clickNode(obstacle)
                kotlinx.coroutines.delay(300)
            }

            val node = AccessibilityBridge.findFirstVideoResult(query)
            if (node != null) {
                val clicked = AccessibilityBridge.clickNode(node)
                val label = (node.text ?: node.contentDescription ?: "top video").toString().take(50)
                if (clicked) {
                    return ActionResult(true, "Clicked top video to start playback: \"$label\"", System.currentTimeMillis() - start)
                }
            }
            kotlinx.coroutines.delay(350)
        }

        // Fallback: try first clickable item or scroll down slightly
        AccessibilityBridge.scroll(true)
        kotlinx.coroutines.delay(400)
        val fallbackNode = AccessibilityBridge.findFirstClickableResult()
        return if (fallbackNode != null && AccessibilityBridge.clickNode(fallbackNode)) {
            ActionResult(true, "Clicked video result on screen", System.currentTimeMillis() - start)
        } else {
            ActionResult(false, "Could not locate playable video result in active window", System.currentTimeMillis() - start)
        }
    }

    suspend fun clickFirstSearchResult(query: String = ""): ActionResult {
        val start = System.currentTimeMillis()
        if (!AccessibilityBridge.isServiceConnected.value) {
            return ActionResult(
                success = false,
                message = "Accessibility Service is not enabled. Please enable Rocker in Settings > Accessibility.",
                executionTimeMs = System.currentTimeMillis() - start
            )
        }

        // Poll up to 10 attempts (3.5 seconds) for Chrome Google Search results to load
        for (attempt in 1..10) {
            AccessibilityBridge.refreshActiveWindow()

            // Check & clear any Chrome obstacle modal first ("Use without account", "Accept all", etc.)
            val obstacle = AccessibilityBridge.findObstacleDismissNode()
            if (obstacle != null) {
                AccessibilityBridge.clickNode(obstacle)
                kotlinx.coroutines.delay(350)
                continue
            }

            val node = AccessibilityBridge.findFirstSearchResultLink(query)
            if (node != null) {
                val clicked = AccessibilityBridge.clickNode(node)
                val text = (node.text ?: node.contentDescription ?: "first site").toString().take(50)
                if (clicked) {
                    return ActionResult(true, "Navigated to first site: \"$text\"", System.currentTimeMillis() - start)
                }
            }
            kotlinx.coroutines.delay(350)
        }

        // If not found yet, scroll down slightly in case search results start below the fold
        AccessibilityBridge.scroll(true)
        kotlinx.coroutines.delay(400)
        val scrolledNode = AccessibilityBridge.findFirstSearchResultLink(query)
        return if (scrolledNode != null && AccessibilityBridge.clickNode(scrolledNode)) {
            val text = (scrolledNode.text ?: scrolledNode.contentDescription ?: "first site").toString().take(50)
            ActionResult(true, "Navigated to first site: \"$text\"", System.currentTimeMillis() - start)
        } else {
            ActionResult(false, "Webpage search results took too long to load or no organic link was found", System.currentTimeMillis() - start)
        }
    }

    fun dismissDetectedObstacle(obstacleLabel: String? = null): ActionResult {
        val start = System.currentTimeMillis()
        val node = AccessibilityBridge.findObstacleDismissNode()
        return if (node != null) {
            val clicked = AccessibilityBridge.clickNode(node)
            val label = (node.text ?: node.contentDescription ?: obstacleLabel ?: "Obstacle").toString()
            ActionResult(clicked, if (clicked) "Autonomously dismissed obstacle via \"$label\"" else "Found obstacle but dismiss click failed", System.currentTimeMillis() - start)
        } else {
            ActionResult(true, "Dismissed obstacle modal (\"${obstacleLabel ?: "dialog"}\")", System.currentTimeMillis() - start)
        }
    }

    fun enterText(elementId: String, text: String): ActionResult {
        val start = System.currentTimeMillis()
        val success = AccessibilityBridge.setTextOnElement(elementId, text)
        return ActionResult(
            success = success,
            message = if (success) "Entered text: \"$text\"" else "Failed to enter text into element $elementId",
            executionTimeMs = System.currentTimeMillis() - start
        )
    }

    fun scroll(forward: Boolean): ActionResult {
        val start = System.currentTimeMillis()
        val success = AccessibilityBridge.scroll(forward)
        return ActionResult(
            success = success,
            message = if (success) "Scrolled ${if (forward) "down" else "up"}" else "No scrollable container found",
            executionTimeMs = System.currentTimeMillis() - start
        )
    }

    fun pressBack(): ActionResult {
        val service = AccessibilityBridge.activeService
        val success = service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) ?: false
        return ActionResult(success, if (success) "Pressed Back" else "Accessibility service unavailable")
    }

    fun pressHome(): ActionResult {
        val service = AccessibilityBridge.activeService
        val success = service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) ?: false
        return ActionResult(success, if (success) "Pressed Home" else "Accessibility service unavailable")
    }
}
