package com.example.model

enum class UiRole {
    BUTTON,
    SEARCH_BAR,
    INPUT_FIELD,
    LIST_ITEM,
    IMAGE,
    TITLE,
    HEADER,
    TAB,
    SWITCH,
    ICON,
    CONTAINER,
    UNKNOWN
}

data class UiElement(
    val id: String,
    val text: String = "",
    val contentDescription: String? = null,
    val viewIdResourceName: String? = null,
    val className: String = "",
    val packageName: String = "",
    val isClickable: Boolean = false,
    val isEditable: Boolean = false,
    val isScrollable: Boolean = false,
    val isCheckable: Boolean = false,
    val isChecked: Boolean = false,
    val boundsLeft: Int = 0,
    val boundsTop: Int = 0,
    val boundsRight: Int = 0,
    val boundsBottom: Int = 0,
    val role: UiRole = UiRole.UNKNOWN,
    val confidenceScore: Float = 1.0f
) {
    val displayLabel: String
        get() = when {
            text.isNotBlank() -> text
            !contentDescription.isNullOrBlank() -> contentDescription
            !viewIdResourceName.isNullOrBlank() -> viewIdResourceName.substringAfterLast("/")
            else -> "${role.name.lowercase()}#${id.takeLast(4)}"
        }

    val width: Int get() = boundsRight - boundsLeft
    val height: Int get() = boundsBottom - boundsTop
    val centerX: Int get() = boundsLeft + width / 2
    val centerY: Int get() = boundsTop + height / 2
}

data class ScreenSnapshot(
    val packageName: String,
    val activityName: String? = null,
    val elements: List<UiElement> = emptyList(),
    val timestamp: Long = System.currentTimeMillis(),
    val summary: String = "",
    val isRealAccessibility: Boolean = false
) {
    val clickableElements: List<UiElement>
        get() = elements.filter { it.isClickable || it.role == UiRole.BUTTON || it.role == UiRole.TAB }

    val inputFields: List<UiElement>
        get() = elements.filter { it.isEditable || it.role == UiRole.INPUT_FIELD || it.role == UiRole.SEARCH_BAR }

    fun findBestMatch(query: String, preferredRole: UiRole? = null): UiElement? {
        val q = query.trim().lowercase()
        return elements.sortedWith(
            compareByDescending<UiElement> { el ->
                var score = 0
                if (preferredRole != null && el.role == preferredRole) score += 30
                if (el.text.lowercase() == q) score += 50
                else if (el.text.lowercase().contains(q)) score += 30
                if (el.contentDescription?.lowercase()?.contains(q) == true) score += 25
                if (el.viewIdResourceName?.lowercase()?.contains(q) == true) score += 15
                if (el.isClickable) score += 10
                score
            }
        ).firstOrNull()
    }
}
