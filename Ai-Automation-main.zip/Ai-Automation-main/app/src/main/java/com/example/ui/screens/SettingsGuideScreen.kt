package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.preferences.AgentSettings
import com.example.service.RockerVoiceService
import com.example.ui.theme.RockerAmberWarning
import com.example.ui.theme.RockerBackground
import com.example.ui.theme.RockerBorder
import com.example.ui.theme.RockerCyanPrimary
import com.example.ui.theme.RockerGreenSuccess
import com.example.ui.theme.RockerSurface
import com.example.ui.theme.RockerSurfaceVariant
import com.example.ui.theme.RockerTextMuted
import com.example.ui.theme.RockerTextPrimary
import com.example.ui.theme.RockerTextSecondary
import com.example.ui.theme.RockerVioletSecondary

@Composable
fun SettingsGuideScreen(
    settings: AgentSettings,
    isAccessibilityConnected: Boolean,
    onToggleWakeWord: (Boolean) -> Unit,
    onUpdateSensitivity: (Int) -> Unit,
    onToggleVoiceFeedback: (Boolean) -> Unit,
    onSimulateWake: () -> Unit,
    onTestTts: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RockerBackground)
            .padding(16.dp)
    ) {
        // Section: Accessibility Service Setup Guide
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = RockerSurface,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isAccessibilityConnected) RockerGreenSuccess.copy(alpha = 0.5f) else RockerCyanPrimary.copy(alpha = 0.4f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AccessibilityNew,
                                contentDescription = null,
                                tint = if (isAccessibilityConnected) RockerGreenSuccess else RockerCyanPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ACCESSIBILITY AUTOMATION SERVICE",
                                color = RockerTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isAccessibilityConnected) RockerGreenSuccess.copy(alpha = 0.15f) else RockerAmberWarning.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = if (isAccessibilityConnected) "ACTIVE" else "NOT ENABLED",
                                color = if (isAccessibilityConnected) RockerGreenSuccess else RockerAmberWarning,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "The Accessibility Service allows Rocker AI to inspect the active window UI hierarchy, find buttons and inputs, and automate actions on your device without hardcoded coordinates.",
                        color = RockerTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    ElevatedButton(
                        onClick = {
                            try {
                                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = RockerCyanPrimary,
                            contentColor = RockerBackground
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("open_accessibility_settings_button")
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open Android Accessibility Settings", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Section: Offline Wake Word Settings
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = RockerSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Hearing, contentDescription = null, tint = RockerCyanPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Offline Wake Word (\"Hey Rocker\")",
                                    color = RockerTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Runs low-power keyword spotting locally",
                                    color = RockerTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = settings.wakeWordEnabled,
                            onCheckedChange = { onToggleWakeWord(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = RockerCyanPrimary,
                                checkedTrackColor = RockerSurfaceVariant
                            ),
                            modifier = Modifier.testTag("wake_word_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "SENSITIVITY: ${settings.wakeWordSensitivity} / 10",
                        color = RockerTextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Slider(
                        value = settings.wakeWordSensitivity.toFloat(),
                        onValueChange = { onUpdateSensitivity(it.toInt()) },
                        valueRange = 1f..10f,
                        steps = 8,
                        colors = SliderDefaults.colors(
                            thumbColor = RockerCyanPrimary,
                            activeTrackColor = RockerCyanPrimary,
                            inactiveTrackColor = RockerSurfaceVariant
                        ),
                        modifier = Modifier.testTag("sensitivity_slider")
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedButton(
                        onClick = onSimulateWake,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_wake_button")
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null, tint = RockerCyanPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Simulate Wake Trigger (\"Hey Rocker\")", color = RockerCyanPrimary, fontSize = 12.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Section: Offline Voice Feedback (TTS)
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = RockerSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = RockerVioletSecondary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Offline Voice Feedback (TTS)",
                                    color = RockerTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Speaks step progress & confirmation",
                                    color = RockerTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = settings.voiceFeedbackEnabled,
                            onCheckedChange = { onToggleVoiceFeedback(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = RockerVioletSecondary,
                                checkedTrackColor = RockerSurfaceVariant
                            ),
                            modifier = Modifier.testTag("voice_feedback_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = onTestTts,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_tts_button")
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = RockerVioletSecondary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Speech Synthesis Audio", color = RockerVioletSecondary, fontSize = 12.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Section: Foreground Service Toggle
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = RockerSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = RockerCyanPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Background Wake-Word Service",
                                color = RockerTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Keeps agent listening while using other apps",
                                color = RockerTextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ElevatedButton(
                            onClick = { RockerVoiceService.startService(context) },
                            colors = ButtonDefaults.elevatedButtonColors(
                                containerColor = RockerCyanPrimary,
                                contentColor = RockerBackground
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Start Service", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { RockerVoiceService.stopService(context) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Stop Service", fontSize = 12.sp, color = RockerTextSecondary)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
