package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [AgentTaskEntity::class, AgentStepEntity::class, TaskExperienceEntity::class],
    version = 2,
    exportSchema = false
)
abstract class RockerDatabase : RoomDatabase() {
    abstract fun agentDao(): AgentDao

    companion object {
        @Volatile
        private var INSTANCE: RockerDatabase? = null

        fun getDatabase(context: Context): RockerDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RockerDatabase::class.java,
                    "rocker_agent_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
