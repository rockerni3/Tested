package com.example.accessibility

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.example.model.ScreenSnapshot
import com.example.model.UiElement
import com.example.model.UiRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

object AccessibilityBridge {
    private val _isServiceConnected = MutableStateFlow(false)
    val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

    private val _currentSnapshot = MutableStateFlow<ScreenSnapshot?>(null)
    val currentSnapshot: StateFlow<ScreenSnapshot?> = _currentSnapshot.asStateFlow()

    private val liveNodeMap = ConcurrentHashMap<String, AccessibilityNodeInfo>()

    var activeService: RockerAccessibilityService? = null

    fun onServiceConnected(service: RockerAccessibilityService) {
        activeService = service
        _isServiceConnected.value = true
        refreshActiveWindow()
    }

    fun onServiceDisconnected() {
        activeService = null
        _isServiceConnected.value = false
        liveNodeMap.clear()
        _currentSnapshot.value = null
    }

    fun refreshActiveWindow() {
        activeService?.captureCurrentWindow()
    }

    fun updateScreenHierarchy(root: AccessibilityNodeInfo?) {
        if (root == null) return
        liveNodeMap.clear()

        val elements = mutableListOf<UiElement>()
        traverseNode(root, elements)

        val pkgName = root.packageName?.toString() ?: "unknown"
        val snapshot = ScreenSnapshot(
            packageName = pkgName,
            elements = elements,
            timestamp = System.currentTimeMillis(),
            summary = "Screen of $pkgName with ${elements.size} elements",
            isRealAccessibility = true
        )
        _currentSnapshot.value = snapshot
    }

    private fun traverseNode(node: AccessibilityNodeInfo, elements: MutableList<UiElement>) {
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        // Ignore zero-size nodes outside visible screen
        if (bounds.width() > 0 && bounds.height() > 0) {
            val elementId = "node_${node.hashCode()}_${bounds.left}_${bounds.top}"
            liveNodeMap[elementId] = node

            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString()
            val cls = node.className?.toString() ?: ""
            val resName = node.viewIdResourceName

            val role = inferRole(node, text, desc, cls, resName)

            elements.add(
                UiElement(
                    id = elementId,
                    text = text,
                    contentDescription = desc,
                    viewIdResourceName = resName,
                    className = cls,
                    packageName = node.packageName?.toString() ?: "",
                    isClickable = node.isClickable,
                    isEditable = node.isEditable,
                    isScrollable = node.isScrollable,
                    isCheckable = node.isCheckable,
                    isChecked = node.isChecked,
                    boundsLeft = bounds.left,
                    boundsTop = bounds.top,
                    boundsRight = bounds.right,
                    boundsBottom = bounds.bottom,
                    role = role
                )
            )
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            traverseNode(child, elements)
        }
    }

    private fun inferRole(
        node: AccessibilityNodeInfo,
        text: String,
        desc: String?,
        className: String,
        resName: String?
    ): UiRole {
        val combined = ("$text $desc $resName $className").lowercase()
        return when {
            combined.contains("search") || (node.isEditable && combined.contains("query")) -> UiRole.SEARCH_BAR
            node.isEditable || className.contains("EditText", ignoreCase = true) -> UiRole.INPUT_FIELD
            node.isClickable && (className.contains("Button", ignoreCase = true) || combined.contains("btn")) -> UiRole.BUTTON
            className.contains("Switch", ignoreCase = true) || className.contains("CheckBox", ignoreCase = true) -> UiRole.SWITCH
            className.contains("Tab", ignoreCase = true) -> UiRole.TAB
            node.isScrollable || className.contains("RecyclerView", ignoreCase = true) || className.contains("ListView", ignoreCase = true) -> UiRole.LIST_ITEM
            className.contains("ImageView", ignoreCase = true) || className.contains("Image", ignoreCase = true) -> UiRole.IMAGE
            node.isClickable -> UiRole.BUTTON
            text.isNotBlank() && boundsIsTitle(node) -> UiRole.TITLE
            else -> UiRole.CONTAINER
        }
    }

    private fun boundsIsTitle(node: AccessibilityNodeInfo): Boolean {
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        return bounds.top < 400 && bounds.height() > 40
    }

    fun getNodeById(id: String): AccessibilityNodeInfo? = liveNodeMap[id]

    fun clickElement(id: String): Boolean {
        val node = liveNodeMap[id] ?: return false
        return clickNode(node)
    }

    fun clickNode(node: AccessibilityNodeInfo): Boolean {
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        var target: AccessibilityNodeInfo? = node
        while (target != null && !target.isClickable) {
            target = target.parent
        }
        val a11ySuccess = (target ?: node).performAction(AccessibilityNodeInfo.ACTION_CLICK)

        // For WebViews (Chrome search results) and custom layouts (YouTube), accessibility performAction
        // often silently fails or isn't forwarded by Chromium. Dispatch hardware touch gesture tap:
        val service = activeService
        if (service != null && bounds.width() > 0 && bounds.height() > 0) {
            val cx = bounds.centerX().toFloat()
            val cy = bounds.centerY().toFloat()
            service.dispatchClickGesture(cx, cy)
            return true
        }

        return a11ySuccess
    }

    fun findAndClickMatching(query: String): Boolean {
        refreshActiveWindow()
        val q = query.lowercase().trim()
        val match = liveNodeMap.values.firstOrNull { node ->
            val label = "${node.text ?: ""} ${node.contentDescription ?: ""} ${node.viewIdResourceName ?: ""}".lowercase()
            label.contains(q)
        } ?: return false
        return clickNode(match)
    }

    fun findFirstClickableResult(): AccessibilityNodeInfo? {
        refreshActiveWindow()
        return liveNodeMap.values.firstOrNull { node ->
            val isClickable = node.isClickable || node.parent?.isClickable == true
            val hasText = !node.text.isNullOrBlank() || !node.contentDescription.isNullOrBlank()
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            isClickable && hasText && bounds.top > 200 && bounds.height() > 50
        }
    }

    fun findAndClickCameraShutter(): Boolean {
        refreshActiveWindow()
        val shutterTerms = listOf(
            "shutter", "take picture", "take photo", "capture", "photo", "snap", "record",
            "shutter button", "camera shutter", "snap button", "take a photo", "capture photo"
        )
        val shutterResIds = listOf(
            "shutter_button", "v9_shutter_button_internal", "bottom_snap_button",
            "btn_done", "camera_shutter", "capture_button", "intent_done"
        )

        // Pass 1: Semantic search by description or resource ID
        val matchedNode = liveNodeMap.values.firstOrNull { node ->
            val desc = "${node.text ?: ""} ${node.contentDescription ?: ""}".lowercase().trim()
            val resId = node.viewIdResourceName?.lowercase() ?: ""
            val isShutterText = shutterTerms.any { desc.contains(it) }
            val isShutterRes = shutterResIds.any { resId.contains(it) }
            (isShutterText || isShutterRes) && (node.isClickable || node.parent?.isClickable == true)
        }

        if (matchedNode != null && clickNode(matchedNode)) {
            return true
        }

        // Pass 2: Fallback to prominent bottom-center circular trigger (standard across all OEM camera apps)
        val service = activeService
        val metrics = service?.resources?.displayMetrics
        val screenWidth = metrics?.widthPixels ?: 1080
        val screenHeight = metrics?.heightPixels ?: 2400

        val bottomCenterNode = liveNodeMap.values.firstOrNull { node ->
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            val isClickable = node.isClickable || node.parent?.isClickable == true
            val isBottomCenter = bounds.centerY().toDouble() > screenHeight * 0.65 &&
                    bounds.centerX().toDouble() in (screenWidth * 0.25)..(screenWidth * 0.75) &&
                    bounds.width() in 80..500 && bounds.height() in 80..500
            isClickable && isBottomCenter
        }

        if (bottomCenterNode != null && clickNode(bottomCenterNode)) {
            return true
        }

        // Pass 3: Dispatch physical tap gesture at the canonical bottom-center shutter point
        if (service != null) {
            val cx = screenWidth / 2f
            val cy = screenHeight * 0.85f
            service.dispatchClickGesture(cx, cy)
            return true
        }

        return false
    }

    fun findHamburgerMenuNode(): AccessibilityNodeInfo? {
        refreshActiveWindow()
        val drawerTerms = listOf(
            "open navigation drawer", "navigation drawer", "menu", "drawer",
            "open menu", "show menu", "more options", "navigate up", "main menu"
        )
        return liveNodeMap.values.firstOrNull { node ->
            val text = (node.text?.toString() ?: node.contentDescription?.toString() ?: "").lowercase().trim()
            val resId = (node.viewIdResourceName ?: "").lowercase()
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            val isClickable = node.isClickable || node.parent?.isClickable == true
            val isTopLeft = bounds.top < 450 && bounds.left < 320
            val isDrawerLabel = drawerTerms.any { text == it || text.contains(it) } || resId.contains("drawer") || resId.contains("menu")
            isClickable && (isDrawerLabel || (isTopLeft && bounds.width() in 35..250))
        }
    }

    fun findSemanticElement(keywords: List<String>): AccessibilityNodeInfo? {
        refreshActiveWindow()
        val cleanTerms = keywords.map { it.lowercase().trim() }.filter { it.isNotBlank() }
        if (cleanTerms.isEmpty()) return null

        // Pass 1: Exact label matches
        for (term in cleanTerms) {
            val exact = liveNodeMap.values.firstOrNull { node ->
                val label = "${node.text ?: ""} ${node.contentDescription ?: ""}".lowercase().trim()
                val isClickable = node.isClickable || node.parent?.isClickable == true
                isClickable && label == term
            }
            if (exact != null) return exact
        }

        // Pass 2: Contains phrase
        for (term in cleanTerms) {
            val containsMatch = liveNodeMap.values.firstOrNull { node ->
                val label = "${node.text ?: ""} ${node.contentDescription ?: ""}".lowercase().trim()
                val isClickable = node.isClickable || node.parent?.isClickable == true
                isClickable && label.contains(term)
            }
            if (containsMatch != null) return containsMatch
        }

        // Pass 3: Contains individual key words
        val words = cleanTerms.flatMap { it.split(" ") }
            .filter { it.length > 2 && !it.equals("the", true) && !it.equals("and", true) && !it.equals("app", true) }

        return liveNodeMap.values.firstOrNull { node ->
            val label = "${node.text ?: ""} ${node.contentDescription ?: ""}".lowercase().trim()
            val isClickable = node.isClickable || node.parent?.isClickable == true
            isClickable && words.any { label.contains(it) }
        }
    }

    fun findFirstVideoResult(query: String? = null): AccessibilityNodeInfo? {
        refreshActiveWindow()
        val ignoreTerms = setOf("search", "explore", "subscriptions", "library", "shorts", "all", "videos", "unwatched", "watched", "filter", "cast", "notifications", "you", "home")
        val cleanQuery = query?.lowercase()?.trim() ?: ""

        val keywords = cleanQuery.split(" ", "-", "_", "+")
            .filter { it.length > 2 && !it.equals("song", true) && !it.equals("latest", true) && !it.equals("play", true) && !it.equals("video", true) && !it.equals("from", true) }

        // 1. Try finding a video result matching query keywords
        if (keywords.isNotEmpty()) {
            val matched = liveNodeMap.values.firstOrNull { node ->
                val text = (node.text?.toString() ?: node.contentDescription?.toString() ?: "").lowercase()
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                val isClickable = node.isClickable || node.parent?.isClickable == true
                val isNotAd = !text.contains("sponsored") && !text.contains("ad •") && !text.startsWith("ad ")
                val isNotShorts = !text.contains("shorts") && !text.contains("#shorts")
                isClickable && bounds.top in 180..2200 && bounds.height() > 50 && isNotAd && isNotShorts && keywords.any { text.contains(it) }
            }
            if (matched != null) return matched
        }

        // 2. Fallback to first organic video tile (any non-header clickable container with substantive description or title)
        return liveNodeMap.values.firstOrNull { node ->
            val text = (node.text?.toString() ?: node.contentDescription?.toString() ?: "").trim()
            val lower = text.lowercase()
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            val isClickable = node.isClickable || node.parent?.isClickable == true
            val isNotIgnore = ignoreTerms.none { lower == it }
            val isNotAd = !lower.startsWith("ad") && !lower.contains("sponsored") && !lower.contains("ad •")
            val isNotShorts = !lower.contains("shorts") && !lower.contains("#shorts")
            isClickable && bounds.top in 200..2200 && bounds.height() > 60 && text.length > 10 && isNotIgnore && isNotAd && isNotShorts
        } ?: findFirstClickableResult()
    }

    fun findFirstSearchResultLink(query: String? = null): AccessibilityNodeInfo? {
        refreshActiveWindow()
        val ignoreTerms = setOf("search", "google", "all", "images", "videos", "news", "maps", "shopping", "tools", "filter", "filters", "sign in", "clear", "web", "more")
        val queryKeywords = query?.lowercase()?.split(" ")?.filter { it.length > 2 } ?: emptyList()

        // Pass 1: Result specifically matching query keywords in headline
        if (queryKeywords.isNotEmpty()) {
            val matched = liveNodeMap.values.firstOrNull { node ->
                val text = (node.text?.toString() ?: node.contentDescription?.toString() ?: "").trim()
                val lower = text.lowercase()
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                val isClickable = node.isClickable || node.parent?.isClickable == true
                val isValidLocation = bounds.top in 200..2000 && bounds.height() > 30
                val isNotIgnore = ignoreTerms.none { lower == it }
                val matchesKeyword = queryKeywords.any { lower.contains(it) }
                val isNotAd = !lower.startsWith("ad") && !lower.contains("sponsored")

                isClickable && isValidLocation && isNotIgnore && isNotAd && matchesKeyword && text.length > 6
            }
            if (matched != null) return matched
        }

        // Pass 2: Any prominent organic search headline or URL link in the search content area
        return liveNodeMap.values.firstOrNull { node ->
            val text = (node.text?.toString() ?: node.contentDescription?.toString() ?: "").trim()
            val lower = text.lowercase()
            val bounds = Rect()
            node.getBoundsInScreen(bounds)

            val isClickable = node.isClickable || node.parent?.isClickable == true
            val isValidLocation = bounds.top in 200..2000 && bounds.height() > 30
            val isNotIgnore = ignoreTerms.none { lower == it }
            val isNotAd = !lower.startsWith("ad") && !lower.contains("sponsored")
            val isHeadlineOrLink = text.length > 8 && (lower.contains("http") || lower.contains(".com") || lower.contains(".org") || lower.contains("wiki") || !lower.startsWith("search"))

            isClickable && isValidLocation && isNotIgnore && isNotAd && isHeadlineOrLink
        } ?: findFirstClickableResult()
    }

    fun findObstacleDismissNode(): AccessibilityNodeInfo? {
        refreshActiveWindow()
        val obstacleDismissTerms = listOf(
            "use without an account",
            "continue without an account",
            "without an account",
            "stay signed out",
            "accept & continue",
            "accept and continue",
            "accept all",
            "i agree",
            "agree",
            "skip ad",
            "skip",
            "close ad",
            "close",
            "dismiss",
            "no thanks",
            "not now",
            "continue as guest",
            "got it",
            "allow"
        )

        return liveNodeMap.values.firstOrNull { node ->
            val isClickable = node.isClickable || node.parent?.isClickable == true
            val label = "${node.text ?: ""} ${node.contentDescription ?: ""}".lowercase().trim()
            isClickable && obstacleDismissTerms.any { term -> label == term || label.contains(term) }
        }
    }

    fun setTextOnElement(id: String, text: String): Boolean {
        val node = liveNodeMap[id] ?: return false
        val args = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(forward: Boolean): Boolean {
        val scrollableNode = liveNodeMap.values.firstOrNull { it.isScrollable }
        if (scrollableNode != null) {
            val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            if (scrollableNode.performAction(action)) return true
        }

        // Gesture scroll fallback
        val service = activeService
        if (service != null) {
            val startY = if (forward) 1400f else 600f
            val endY = if (forward) 600f else 1400f
            service.dispatchScrollGesture(500f, startY, 500f, endY)
            return true
        }
        return false
    }
}
