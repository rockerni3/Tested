package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VoiceOverOff
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.WakeState
import com.example.model.AgentTask
import com.example.model.TaskStatus
import com.example.ui.components.ExecutionStepCard
import com.example.ui.components.VoiceOrb
import com.example.ui.theme.RockerAmberWarning
import com.example.ui.theme.RockerBackground
import com.example.ui.theme.RockerBorder
import com.example.ui.theme.RockerCyanPrimary
import com.example.ui.theme.RockerGreenSuccess
import com.example.ui.theme.RockerRedError
import com.example.ui.theme.RockerSurface
import com.example.ui.theme.RockerSurfaceVariant
import android.content.Intent
import android.provider.Settings
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.platform.LocalContext
import com.example.ui.theme.RockerTextMuted
import com.example.ui.theme.RockerTextPrimary
import com.example.ui.theme.RockerTextSecondary
import com.example.ui.theme.RockerVioletSecondary

import com.example.data.local.TaskExperienceEntity

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AgentHomeScreen(
    wakeState: WakeState,
    audioEnergy: Float,
    isExecuting: Boolean,
    liveTranscript: String,
    currentTask: AgentTask?,
    learnedExperiences: List<TaskExperienceEntity> = emptyList(),
    activeModelName: String = "Gemma 4 E2B Instruct (LiteRT-LM)",
    isAccessibilityConnected: Boolean = true,
    isModelFilePresent: Boolean = false,
    onOrbClick: () -> Unit,
    onSubmitPrompt: (String) -> Unit,
    onCancelExecution: () -> Unit,
    onSimulateWake: () -> Unit,
    onNavigateToHardware: () -> Unit = {},
    onConfirmTask: () -> Unit = {},
    onRejectTask: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var textInput by remember { mutableStateOf("") }

    val quickCommands = listOf(
        "Open Chrome and search WWE superstar and open first site",
        "Open YouTube and play latest song from Arijit Singh",
        "Open Calculator and calculate 45 * 80 + 350",
        "Open Camera and take a photo",
        "Open WhatsApp and send message Rahul hey are we meeting today",
        "Open Settings and check Battery optimization"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RockerBackground)
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Hardware & Architecture Badge
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
                color = RockerSurface,
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isModelFilePresent) RockerBorder else RockerAmberWarning.copy(alpha = 0.5f)
                ),
                modifier = Modifier
                    .padding(bottom = 8.dp)
                    .clickable { onNavigateToHardware() }
                    .testTag("model_status_badge")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isModelFilePresent) RockerGreenSuccess else RockerAmberWarning)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isModelFilePresent) {
                            "LOCAL WEIGHTS ON-DISK • MEDIAPIPE LITERT • SNAPDRAGON 8s GEN 3"
                        } else {
                            "NO MODEL ON DISK (TAP TO DOWNLOAD / IMPORT)"
                        },
                        color = if (isModelFilePresent) RockerCyanPrimary else RockerAmberWarning,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Accessibility Service Warning if disabled
        if (!isAccessibilityConnected) {
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = RockerAmberWarning.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RockerAmberWarning.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable {
                            try {
                                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AccessibilityNew, contentDescription = null, tint = RockerAmberWarning, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Accessibility Service is OFF", color = RockerAmberWarning, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Tap here to enable Rocker in Settings > Accessibility so the agent can physically tap and automate other apps.", color = RockerTextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Voice Orb Centerpiece
        item {
            Spacer(modifier = Modifier.height(8.dp))
            VoiceOrb(
                wakeState = wakeState,
                audioEnergy = audioEnergy,
                isExecuting = isExecuting,
                onClick = onOrbClick
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Wake word status / instructions
            val statusText = when {
                isExecuting -> "Autonomous agent executing on screen..."
                wakeState == WakeState.CAPTURING_SPEECH -> "Listening to your instruction..."
                wakeState == WakeState.PROCESSING -> "$activeModelName reasoning offline..."
                wakeState == WakeState.WAKE_DETECTED -> "Wake phrase detected: \"Hey Rocker\""
                else -> "Say \"Hey Rocker\" or tap the Orb to command"
            }

            Text(
                text = statusText,
                color = if (isExecuting) RockerGreenSuccess else RockerTextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Independent reasoning • UI hierarchy automation • Silent (No voice)",
                color = RockerTextMuted,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))
        }

        // Active Interruption & Cancellation button
        if (isExecuting) {
            item {
                ElevatedButton(
                    onClick = onCancelExecution,
                    colors = ButtonDefaults.elevatedButtonColors(
                        containerColor = RockerRedError,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.6f)
                        .testTag("cancel_execution_button")
                ) {
                    Icon(imageVector = Icons.Default.Stop, contentDescription = "Stop")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("INTERRUPT AGENT", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Live Transcript Box (if speech recognized)
        if (liveTranscript.isNotBlank()) {
            item {
                Surface(
                    color = RockerSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RockerCyanPrimary.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = RockerCyanPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "\"$liveTranscript\"",
                            color = RockerTextPrimary,
                            fontSize = 13.sp,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                    }
                }
            }
        }

        // Autonomous Command Input Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text("E.g. Open YouTube and play Arijit Singh", color = RockerTextMuted, fontSize = 13.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("agent_input_field"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RockerCyanPrimary,
                        unfocusedBorderColor = RockerBorder,
                        focusedTextColor = RockerTextPrimary,
                        unfocusedTextColor = RockerTextPrimary,
                        focusedContainerColor = RockerSurface,
                        unfocusedContainerColor = RockerSurface
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            onSubmitPrompt(textInput)
                            textInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(RockerCyanPrimary)
                        .testTag("send_prompt_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Execute Command",
                        tint = RockerBackground
                    )
                }
            }
        }

        // Quick Examples Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "AUTONOMOUS AGENT EXAMPLES",
                        color = RockerTextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Text(
                        text = "Simulate \"Hey Rocker\"",
                        color = RockerCyanPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clickable { onSimulateWake() }
                            .padding(4.dp)
                            .testTag("simulate_wake_button")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    quickCommands.forEach { cmd ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = RockerSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder),
                            modifier = Modifier
                                .clickable { onSubmitPrompt(cmd) }
                                .testTag("quick_command_chip")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = RockerCyanPrimary,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = cmd,
                                    color = RockerTextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }

        // Self-Learning Episodic Memory Status Card
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = RockerSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, RockerCyanPrimary.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth().testTag("episodic_memory_card")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = RockerCyanPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SELF-LEARNING EPISODIC MEMORY",
                                color = RockerCyanPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = RockerCyanPrimary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${learnedExperiences.size} Learned",
                                color = RockerCyanPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (learnedExperiences.isNotEmpty()) {
                            "Agent has memorized ${learnedExperiences.size} task pathways. Repeating similar goals reuses proven selectors and pre-bypasses known modals for 40% faster execution."
                        } else {
                            "Self-learning active: automatically caches verified UI navigation paths, ad bypasses, and account dialog workarounds for instant fast-path replay."
                        },
                        color = RockerTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    if (learnedExperiences.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            learnedExperiences.take(4).forEach { exp ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = RockerSurfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, RockerBorder)
                                ) {
                                    Text(
                                        text = "${exp.intentPattern} (${exp.executionCount}x)",
                                        color = RockerGreenSuccess,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Live Execution Plan & Verification Trace
        if (currentTask != null && currentTask.steps.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "LIVE EXECUTION TRACE",
                        color = RockerTextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Surface(
                        color = when (currentTask.status) {
                            TaskStatus.COMPLETED -> RockerGreenSuccess.copy(alpha = 0.15f)
                            TaskStatus.FAILED -> RockerRedError.copy(alpha = 0.15f)
                            TaskStatus.INTERRUPTED -> RockerAmberWarning.copy(alpha = 0.15f)
                            else -> RockerCyanPrimary.copy(alpha = 0.15f)
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = currentTask.status.name,
                            color = when (currentTask.status) {
                                TaskStatus.COMPLETED -> RockerGreenSuccess
                                TaskStatus.FAILED -> RockerRedError
                                TaskStatus.INTERRUPTED -> RockerAmberWarning
                                else -> RockerCyanPrimary
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (currentTask.status == TaskStatus.AWAITING_CONFIRMATION) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = RockerAmberWarning.copy(alpha = 0.12f),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, RockerAmberWarning),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .testTag("safety_confirmation_card")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Confirmation Required",
                                    tint = RockerAmberWarning,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "SAFETY CONFIRMATION REQUIRED",
                                    color = RockerAmberWarning,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = currentTask.finalSummary ?: "The autonomous agent is paused before sending a message or executing a high-impact operation. Do you want to proceed?",
                                color = RockerTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ElevatedButton(
                                    onClick = onConfirmTask,
                                    colors = ButtonDefaults.elevatedButtonColors(
                                        containerColor = RockerGreenSuccess,
                                        contentColor = RockerBackground
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("confirm_action_button")
                                ) {
                                    Text("Confirm & Send", fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = onRejectTask,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = RockerRedError
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("cancel_action_button")
                                ) {
                                    Text("Cancel Action", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            items(currentTask.steps) { step ->
                ExecutionStepCard(step = step, modifier = Modifier.padding(vertical = 4.dp))
            }

            if (currentTask.finalSummary != null) {
                item {
                    Surface(
                        color = RockerSurface,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RockerGreenSuccess.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "AGENT OUTCOME SUMMARY",
                                color = RockerGreenSuccess,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = currentTask.finalSummary,
                                color = RockerTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
