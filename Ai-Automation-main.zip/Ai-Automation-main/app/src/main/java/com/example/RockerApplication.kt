package com.example

import android.app.Application
import com.example.data.local.RockerDatabase
import com.example.data.preferences.RockerPreferences

class RockerApplication : Application() {

    lateinit var database: RockerDatabase
        private set

    lateinit var preferences: RockerPreferences
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = RockerDatabase.getDatabase(this)
        preferences = RockerPreferences(this)
    }

    companion object {
        lateinit var instance: RockerApplication
            private set
    }
}
