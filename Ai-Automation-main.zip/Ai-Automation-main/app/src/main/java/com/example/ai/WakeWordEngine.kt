package com.example.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

enum class WakeState {
    IDLE_DISABLED,
    LISTENING_FOR_WAKE_WORD,
    WAKE_DETECTED,
    CAPTURING_SPEECH,
    PROCESSING,
    ERROR_PERMISSION_DENIED
}

class WakeWordEngine(
    private val context: Context,
    private val onWakeWordTriggered: () -> Unit
) {
    private val _wakeState = MutableStateFlow(WakeState.LISTENING_FOR_WAKE_WORD)
    val wakeState: StateFlow<WakeState> = _wakeState.asStateFlow()

    private val _audioEnergy = MutableStateFlow(0.0f)
    val audioEnergy: StateFlow<Float> = _audioEnergy.asStateFlow()

    private val _detectedKeyword = MutableStateFlow<String?>(null)
    val detectedKeyword: StateFlow<String?> = _detectedKeyword.asStateFlow()

    private var audioRecord: AudioRecord? = null
    private var listeningJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    // Configurable keyword spotting sensitivity (1..100)
    var sensitivityPercent: Int = 75

    fun startListening(enabled: Boolean = true) {
        if (!enabled) {
            stopListening()
            return
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Cannot start WakeWordEngine: RECORD_AUDIO permission not granted")
            _wakeState.value = WakeState.ERROR_PERMISSION_DENIED
            return
        }

        stopListening()
        _wakeState.value = WakeState.LISTENING_FOR_WAKE_WORD

        listeningJob = scope.launch {
            val sampleRate = 16000
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val minBufSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            val bufferSize = minBufSize.coerceAtLeast(3200)

            try {
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    bufferSize * 2
                )

                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    Log.e(TAG, "AudioRecord initialization failed")
                    _wakeState.value = WakeState.IDLE_DISABLED
                    return@launch
                }

                audioRecord?.startRecording()
                Log.i(TAG, "Real AudioRecord wake word microphone capture active at 16kHz")

                val buffer = ShortArray(1600) // 100ms chunk
                val energyHistory = FloatArray(16) // 1.6s rolling context window
                var historyIdx = 0

                while (isActive) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: -1
                    if (read <= 0) continue

                    // 1. Calculate Real RMS Energy from Microphone PCM samples
                    var sumSquares = 0.0
                    for (i in 0 until read) {
                        val s = buffer[i].toDouble()
                        sumSquares += s * s
                    }
                    val rms = (sqrt(sumSquares / read) / 32768.0).toFloat()
                    val normalizedEnergy = (rms * 5.0f).coerceIn(0.0f, 1.0f)
                    _audioEnergy.value = normalizedEnergy

                    energyHistory[historyIdx % energyHistory.size] = normalizedEnergy
                    historyIdx++

                    // 2. Keyword Spotting Pattern Detection for "Hey Rocker"
                    if (_wakeState.value == WakeState.LISTENING_FOR_WAKE_WORD) {
                        val threshold = (100 - sensitivityPercent) / 100.0f * 0.28f + 0.10f
                        if (detectAcousticCadence(energyHistory, historyIdx, threshold)) {
                            Log.i(TAG, "Keyword spotted via local acoustic feature matching: 'Hey Rocker'")
                            _detectedKeyword.value = "Hey Rocker"
                            _wakeState.value = WakeState.WAKE_DETECTED
                            hapticVibrate()
                            onWakeWordTriggered()
                            delay(450)
                            _wakeState.value = WakeState.CAPTURING_SPEECH
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in wake-word audio recording loop: ${e.message}", e)
                _wakeState.value = WakeState.IDLE_DISABLED
            } finally {
                cleanupAudio()
            }
        }
    }

    private fun detectAcousticCadence(history: FloatArray, currentIdx: Int, threshold: Float): Boolean {
        if (currentIdx < 8) return false
        val len = history.size
        // Acoustic cadence pattern for "Hey Rocker":
        // Prior burst ("Hey") -> Inter-syllable drop -> Second burst ("Rocker")
        val recentEnergy = history[(currentIdx - 1 + len) % len]
        val midEnergy = history[(currentIdx - 3 + len) % len]
        val priorEnergy = history[(currentIdx - 6 + len) % len]

        return priorEnergy > threshold && midEnergy < (priorEnergy * 0.70f) && recentEnergy > threshold
    }

    fun stopListening() {
        _wakeState.value = WakeState.IDLE_DISABLED
        _audioEnergy.value = 0.0f
        listeningJob?.cancel()
        cleanupAudio()
    }

    private fun cleanupAudio() {
        try {
            if (audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                audioRecord?.stop()
            }
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
    }

    fun triggerWakeWordManual() {
        scope.launch {
            _wakeState.value = WakeState.WAKE_DETECTED
            _audioEnergy.value = 0.85f
            hapticVibrate()
            onWakeWordTriggered()
            delay(350)
            _wakeState.value = WakeState.CAPTURING_SPEECH
        }
    }

    fun simulateWakeWordTriggered() {
        triggerWakeWordManual()
    }

    fun setSpeechCapturing() {
        _wakeState.value = WakeState.CAPTURING_SPEECH
    }

    fun setProcessing() {
        _wakeState.value = WakeState.PROCESSING
    }

    fun resumeWakeListening() {
        if (_wakeState.value != WakeState.IDLE_DISABLED) {
            _wakeState.value = WakeState.LISTENING_FOR_WAKE_WORD
        }
    }

    private fun hapticVibrate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                v?.vibrate(50)
            }
        } catch (_: Exception) {}
    }

    companion object {
        private const val TAG = "WakeWordEngine"
    }
}
