package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.RockerApplication
import com.example.accessibility.AccessibilityBridge
import com.example.ai.AndroidActionEngine
import com.example.ai.AppDiscoveryEngine
import com.example.ai.AgentExecutionEngine
import com.example.ai.DiagnosticInferenceResult
import com.example.ai.LiteRtLmEngine
import com.example.ai.ModelManager
import com.example.ai.ScreenUnderstandingEngine
import com.example.ai.SpeechEngine
import com.example.ai.WakeState
import com.example.ai.WakeWordEngine
import com.example.data.local.AgentTaskEntity
import com.example.data.local.TaskExperienceEntity
import com.example.data.preferences.AgentSettings
import com.example.model.AgentTask
import com.example.model.ModelDownloadState
import com.example.model.ScreenSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class RockerTab {
    AGENT,
    INSPECTOR,
    MODEL_RAM,
    LOGS,
    SETTINGS
}

class RockerViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as RockerApplication
    private val database = app.database
    private val preferences = app.preferences

    val modelManager = ModelManager(application)
    val appDiscovery = AppDiscoveryEngine(application)
    val screenEngine = ScreenUnderstandingEngine()
    val actionEngine = AndroidActionEngine(application)
    val liteRtLm = LiteRtLmEngine(application, modelManager)

    private val _selectedTab = MutableStateFlow(RockerTab.AGENT)
    val selectedTab: StateFlow<RockerTab> = _selectedTab.asStateFlow()

    private val _memoryStats = MutableStateFlow(modelManager.getMemoryStats())
    val memoryStats: StateFlow<Triple<Long, Long, Boolean>> = _memoryStats.asStateFlow()

    private val _diagnosticResult = MutableStateFlow<DiagnosticInferenceResult?>(null)
    val diagnosticResult: StateFlow<DiagnosticInferenceResult?> = _diagnosticResult.asStateFlow()

    private val _isDiagnosticRunning = MutableStateFlow(false)
    val isDiagnosticRunning: StateFlow<Boolean> = _isDiagnosticRunning.asStateFlow()

    val settings: StateFlow<AgentSettings> = preferences.settingsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        AgentSettings()
    )

    val historyTasks: StateFlow<List<AgentTaskEntity>> = database.agentDao().getAllTasks().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val learnedExperiences: StateFlow<List<TaskExperienceEntity>> = database.agentDao().getAllExperiences().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val isAccessibilityConnected: StateFlow<Boolean> = AccessibilityBridge.isServiceConnected

    val currentScreenSnapshot: StateFlow<ScreenSnapshot?> = AccessibilityBridge.currentSnapshot

    val modelDownloadState: StateFlow<ModelDownloadState> = modelManager.downloadState

    val speechEngine: SpeechEngine = SpeechEngine(application) { transcript ->
        onSpeechRecognized(transcript)
    }

    val wakeWordEngine: WakeWordEngine = WakeWordEngine(application) {
        onWakeWordTriggered()
    }

    val executionEngine: AgentExecutionEngine = AgentExecutionEngine(
        context = application,
        agentDao = database.agentDao(),
        appDiscovery = appDiscovery,
        screenEngine = screenEngine,
        actionEngine = actionEngine,
        liteRtLm = liteRtLm
    )

    val currentTask: StateFlow<AgentTask?> = executionEngine.currentTask
    val isExecuting: StateFlow<Boolean> = executionEngine.isExecuting
    val wakeState: StateFlow<WakeState> = wakeWordEngine.wakeState
    val audioEnergy: StateFlow<Float> = wakeWordEngine.audioEnergy
    val isListening: StateFlow<Boolean> = speechEngine.isListening
    val liveTranscript: StateFlow<String> = speechEngine.liveTranscript

    init {
        wakeWordEngine.startListening(settings.value.wakeWordEnabled)
        refreshMemoryStats()
    }

    fun setTab(tab: RockerTab) {
        _selectedTab.value = tab
    }

    fun refreshMemoryStats() {
        _memoryStats.value = modelManager.getMemoryStats()
    }

    fun onWakeWordTriggered() {
        speechEngine.startListening()
    }

    fun triggerWakeWordSimulation() {
        wakeWordEngine.simulateWakeWordTriggered()
    }

    fun startListeningManually() {
        wakeWordEngine.setSpeechCapturing()
        speechEngine.startListening()
    }

    fun stopListeningManually() {
        speechEngine.stopListening()
        wakeWordEngine.resumeWakeListening()
    }

    private fun onSpeechRecognized(transcript: String) {
        wakeWordEngine.setProcessing()
        submitAutonomousPrompt(transcript)
    }

    fun submitAutonomousPrompt(prompt: String) {
        if (prompt.isBlank()) return
        executionEngine.executeAutonomousGoal(prompt)
    }

    fun cancelActiveExecution() {
        executionEngine.cancelExecution()
        wakeWordEngine.resumeWakeListening()
    }

    fun confirmActiveTask() {
        executionEngine.confirmTask()
    }

    fun rejectActiveTask() {
        executionEngine.rejectTask()
    }

    fun runDiagnosticInference(prompt: String = "Explain what Android AccessibilityService is in two sentences.") {
        viewModelScope.launch {
            _isDiagnosticRunning.value = true
            try {
                val result = liteRtLm.runDiagnosticInference(prompt)
                _diagnosticResult.value = result
            } finally {
                _isDiagnosticRunning.value = false
            }
        }
    }

    fun selectModel(modelId: String) {
        modelManager.selectModel(modelId)
        refreshMemoryStats()
    }

    fun triggerModelDownloadOrResume() {
        modelManager.startOrResumeDownload()
    }

    fun downloadFromCustomUrl(url: String) {
        modelManager.startDownloadFromCustomUrl(url)
    }

    fun pauseModelDownload() {
        modelManager.pauseDownload()
    }

    fun unloadModelFromMemory() {
        modelManager.unloadModelFromMemory()
        refreshMemoryStats()
    }

    fun loadModelIntoMemory() {
        modelManager.loadModelIntoMemory()
        refreshMemoryStats()
    }

    fun importLocalModel(uri: android.net.Uri) {
        modelManager.importLocalModelFromUri(uri)
        refreshMemoryStats()
    }

    fun setCustomModelPath(path: String): Boolean {
        val success = modelManager.setCustomModelPath(path)
        refreshMemoryStats()
        return success
    }

    fun deleteModel() {
        modelManager.deleteDownloadedModel()
        refreshMemoryStats()
    }

    fun toggleWakeWord(enabled: Boolean) {
        viewModelScope.launch {
            preferences.updateWakeWordEnabled(enabled)
            wakeWordEngine.startListening(enabled)
        }
    }

    fun updateSensitivity(value: Int) {
        viewModelScope.launch {
            preferences.updateWakeWordSensitivity(value)
        }
    }

    fun toggleVoiceFeedback(enabled: Boolean) {
        viewModelScope.launch {
            preferences.updateVoiceFeedbackEnabled(enabled)
        }
    }

    fun testSpeechSynthesis(sample: String = "Hey Rocker autonomous agent is operational and running completely offline.") {
        speechEngine.speak(sample, settings.value.ttsPitch, settings.value.ttsRate)
    }

    fun clearTaskHistory() {
        viewModelScope.launch {
            database.agentDao().clearAllTasks()
            database.agentDao().clearAllSteps()
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechEngine.cleanup()
        wakeWordEngine.stopListening()
    }
}
