package com.example.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "rocker_preferences")

data class AgentSettings(
    val wakeWordEnabled: Boolean = true,
    val wakeWordPhrase: String = "Hey Rocker",
    val wakeWordSensitivity: Int = 7, // 1 - 10
    val voiceFeedbackEnabled: Boolean = false,
    val ttsPitch: Float = 1.0f,
    val ttsRate: Float = 1.0f,
    val maxStepLimit: Int = 12,
    val maxRetries: Int = 3,
    val sandboxSimulationMode: Boolean = true,
    val snapdragonOptimization: Boolean = true
)

class RockerPreferences(private val context: Context) {

    private object PreferencesKeys {
        val WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        val WAKE_WORD_PHRASE = stringPreferencesKey("wake_word_phrase")
        val WAKE_WORD_SENSITIVITY = intPreferencesKey("wake_word_sensitivity")
        val VOICE_FEEDBACK_ENABLED = booleanPreferencesKey("voice_feedback_enabled")
        val TTS_PITCH = floatPreferencesKey("tts_pitch")
        val TTS_RATE = floatPreferencesKey("tts_rate")
        val MAX_STEP_LIMIT = intPreferencesKey("max_step_limit")
        val MAX_RETRIES = intPreferencesKey("max_retries")
        val SANDBOX_SIMULATION_MODE = booleanPreferencesKey("sandbox_simulation_mode")
        val SNAPDRAGON_OPTIMIZATION = booleanPreferencesKey("snapdragon_optimization")
    }

    val settingsFlow: Flow<AgentSettings> = context.dataStore.data.map { preferences ->
        AgentSettings(
            wakeWordEnabled = preferences[PreferencesKeys.WAKE_WORD_ENABLED] ?: true,
            wakeWordPhrase = preferences[PreferencesKeys.WAKE_WORD_PHRASE] ?: "Hey Rocker",
            wakeWordSensitivity = preferences[PreferencesKeys.WAKE_WORD_SENSITIVITY] ?: 7,
            voiceFeedbackEnabled = preferences[PreferencesKeys.VOICE_FEEDBACK_ENABLED] ?: false,
            ttsPitch = preferences[PreferencesKeys.TTS_PITCH] ?: 1.0f,
            ttsRate = preferences[PreferencesKeys.TTS_RATE] ?: 1.0f,
            maxStepLimit = preferences[PreferencesKeys.MAX_STEP_LIMIT] ?: 12,
            maxRetries = preferences[PreferencesKeys.MAX_RETRIES] ?: 3,
            sandboxSimulationMode = preferences[PreferencesKeys.SANDBOX_SIMULATION_MODE] ?: true,
            snapdragonOptimization = preferences[PreferencesKeys.SNAPDRAGON_OPTIMIZATION] ?: true
        )
    }

    suspend fun updateWakeWordEnabled(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.WAKE_WORD_ENABLED] = enabled }
    }

    suspend fun updateWakeWordPhrase(phrase: String) {
        context.dataStore.edit { it[PreferencesKeys.WAKE_WORD_PHRASE] = phrase }
    }

    suspend fun updateWakeWordSensitivity(sensitivity: Int) {
        context.dataStore.edit { it[PreferencesKeys.WAKE_WORD_SENSITIVITY] = sensitivity }
    }

    suspend fun updateVoiceFeedbackEnabled(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.VOICE_FEEDBACK_ENABLED] = enabled }
    }

    suspend fun updateSandboxSimulation(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.SANDBOX_SIMULATION_MODE] = enabled }
    }

    suspend fun updateSnapdragonOptimization(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.SNAPDRAGON_OPTIMIZATION] = enabled }
    }
}
