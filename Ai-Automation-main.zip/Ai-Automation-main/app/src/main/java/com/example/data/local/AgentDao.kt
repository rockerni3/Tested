package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

data class TaskWithSteps(
    val task: AgentTaskEntity,
    val steps: List<AgentStepEntity>
)

@Dao
interface AgentDao {
    @Query("SELECT * FROM agent_tasks ORDER BY startTime DESC")
    fun getAllTasks(): Flow<List<AgentTaskEntity>>

    @Query("SELECT * FROM agent_tasks WHERE id = :taskId")
    suspend fun getTaskById(taskId: String): AgentTaskEntity?

    @Query("SELECT * FROM agent_steps WHERE taskId = :taskId ORDER BY stepIndex ASC")
    fun getStepsForTask(taskId: String): Flow<List<AgentStepEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: AgentTaskEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStep(step: AgentStepEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSteps(steps: List<AgentStepEntity>)

    @Query("DELETE FROM agent_tasks")
    suspend fun clearAllTasks()

    @Query("DELETE FROM agent_steps")
    suspend fun clearAllSteps()

    @Query("SELECT * FROM task_experiences ORDER BY executionCount DESC, lastSuccessTimestamp DESC")
    fun getAllExperiences(): Flow<List<TaskExperienceEntity>>

    @Query("SELECT * FROM task_experiences WHERE intentPattern = :intentPattern LIMIT 1")
    suspend fun getExperienceByPattern(intentPattern: String): TaskExperienceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExperience(experience: TaskExperienceEntity)

    @Query("DELETE FROM task_experiences")
    suspend fun clearAllExperiences()
}
