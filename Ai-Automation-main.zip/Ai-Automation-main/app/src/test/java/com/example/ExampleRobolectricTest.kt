package com.example

import com.example.ai.ScreenUnderstandingEngine
import com.example.model.UiRole
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleRobolectricTest {

    @Test
    fun `screen understanding engine parses sandbox hierarchy`() {
        val engine = ScreenUnderstandingEngine()
        val snapshot = engine.generateSandboxSnapshot("YouTube", "HOME")
        assertEquals("com.google.android.youtube", snapshot.packageName)
        assertTrue(snapshot.elements.isNotEmpty())

        val comprehension = engine.analyzeScreen(snapshot)
        assertNotNull(comprehension.searchBarElement)
        assertEquals(UiRole.SEARCH_BAR, comprehension.searchBarElement?.role)
    }

    @Test
    fun `calculator sandbox provides buttons and display`() {
        val engine = ScreenUnderstandingEngine()
        val snapshot = engine.generateSandboxSnapshot("Calculator", "HOME")
        assertEquals("com.google.android.calculator", snapshot.packageName)
        assertTrue(snapshot.elements.any { it.text == "=" })
        assertTrue(snapshot.elements.any { it.text == "+" })
    }

    @Test
    fun `camera sandbox provides shutter button`() {
        val engine = ScreenUnderstandingEngine()
        val snapshot = engine.generateSandboxSnapshot("Camera", "HOME")
        assertEquals("com.android.camera", snapshot.packageName)
        assertTrue(snapshot.elements.any { it.isClickable && (it.text.contains("Photo") || it.id.contains("shutter")) })
    }

    @Test
    fun `clock sandbox provides alarm controls`() {
        val engine = ScreenUnderstandingEngine()
        val snapshot = engine.generateSandboxSnapshot("Clock", "HOME")
        assertEquals("com.google.android.deskclock", snapshot.packageName)
        assertTrue(snapshot.elements.any { it.role == UiRole.TAB })
    }

    @Test
    fun `chrome account onboarding obstacle is detected`() {
        val engine = ScreenUnderstandingEngine()
        val snapshot = engine.generateSandboxSnapshot("Chrome", "ACCOUNT_PROMPT")
        val obstacle = engine.detectInterstitialObstacle(snapshot)
        assertNotNull(obstacle)
        assertEquals("Account Setup Dialog", obstacle?.title)
        assertTrue(obstacle?.dismissLabel?.contains("account", ignoreCase = true) == true)
    }

    @Test
    fun `chrome ad popup obstacle is detected`() {
        val engine = ScreenUnderstandingEngine()
        val snapshot = engine.generateSandboxSnapshot("Chrome", "AD_POPUP")
        val obstacle = engine.detectInterstitialObstacle(snapshot)
        assertNotNull(obstacle)
        assertEquals("Advertisement Modal", obstacle?.title)
    }

    @Test
    fun `chrome search results provide first organic site link`() {
        val engine = ScreenUnderstandingEngine()
        val snapshot = engine.generateSandboxSnapshot("Chrome", "SEARCH_RESULTS", "wwe superstar")
        val link = engine.findFirstOrganicResultLink(snapshot, "wwe")
        assertNotNull(link)
        assertTrue(link?.isClickable == true)
        assertTrue(link?.text?.contains("WWE", ignoreCase = true) == true)
    }

    @Test
    fun `gemma 4 e2b it is default model and e4b it is available`() {
        val defaultModel = com.example.model.AVAILABLE_MODELS.first()
        assertEquals("gemma-4-e2b-it", defaultModel.id)
        assertTrue(defaultModel.name.contains("Gemma 4 E2B", ignoreCase = true))
        assertTrue(defaultModel.sourceUrl.contains("litert-community/gemma-4-E2B-it-litert-lm"))

        val e4bModel = com.example.model.AVAILABLE_MODELS.firstOrNull { it.id == "gemma-4-e4b-it" }
        assertNotNull(e4bModel)
        assertTrue(e4bModel?.sourceUrl?.contains("litert-community/gemma-4-E4B-it-litert-lm") == true)

        val defaultState = com.example.model.ModelDownloadState()
        assertEquals("gemma-4-e2b-it", defaultState.selectedModelId)
    }

    @Test
    fun `available models list contains smollm fast open download model`() {
        val models = com.example.model.AVAILABLE_MODELS
        assertTrue(models.any { it.id == "smollm-135m-fast" })
        val smol = models.first { it.id == "smollm-135m-fast" }
        assertTrue(smol.sourceUrl.contains("resolve/main"))
        assertTrue(smol.sourceUrl.endsWith(".gguf"))
        assertEquals(94, smol.requiredStorageMb)
    }

    @Test
    fun `compound query extraction isolates search term from downstream actions`() {
        val engine = com.example.ai.LiteRtLmEngine()

        val pattern = engine.computePatternKey("open chrome and search wwe superstar and open first site", "com.android.chrome")
        assertEquals("chrome:search_and_open_first_site", pattern)

        val apps = listOf(
            com.example.ai.InstalledApp("Chrome", "com.android.chrome"),
            com.example.ai.InstalledApp("YouTube", "com.google.android.youtube")
        )

        kotlinx.coroutines.runBlocking {
            val plan = engine.generateAutonomousPlan(
                "open chrome and search wwe superstar and open first site",
                apps,
                null
            )
            assertEquals("com.android.chrome", plan.targetApp.packageName)
            assertTrue(plan.steps.any { it.actionType == com.example.model.AgentActionType.LAUNCH_APPLICATION })
            assertTrue(plan.steps.any { it.actionType == com.example.model.AgentActionType.INSPECT_SCREEN })
            assertTrue(plan.steps.any { it.target.contains("First Organic Result Link") })
            val launchStep = plan.steps.first { it.actionType == com.example.model.AgentActionType.LAUNCH_APPLICATION }
            assertEquals("wwe superstar", launchStep.parameters["query"])
        }
    }

    @Test
    fun `diagnostic inference engine reports truthful offline mode and prompt metrics`() {
        val engine = com.example.ai.LiteRtLmEngine()
        kotlinx.coroutines.runBlocking {
            val result = engine.runDiagnosticInference("Explain what Android AccessibilityService is in two sentences.")
            assertTrue(result.isOffline)
            assertFalse(result.isLocalWeightsLoaded)
            assertTrue(result.promptTokens > 0)
            assertTrue(result.generatedResponse.isNotBlank())
            assertTrue(result.generatedResponse.contains("NO LOCAL MODEL FILE DETECTED ON DISK"))
            assertTrue(result.runtimeVersion.contains("LiteRT-LM"))
            assertTrue(result.executionBackend.contains("Qualcomm Snapdragon 8s Gen 3"))
        }
    }

    @Test
    fun `screen understanding engine redacts sensitive information such as OTP and passwords`() {
        val engine = ScreenUnderstandingEngine()
        val redactedOtp = engine.redactSensitiveInformation("Your verification OTP is 492810 for account login.")
        assertTrue(redactedOtp.contains("[REDACTED_OTP]"))
        assertFalse(redactedOtp.contains("492810"))

        val redactedPassword = engine.redactSensitiveInformation("Please enter password SecretPass123! here.")
        assertTrue(redactedPassword.contains("[REDACTED_PASSWORD]"))

        val redactedPin = engine.redactSensitiveInformation("Confirm transaction with pin 7789.")
        assertTrue(redactedPin.contains("[REDACTED_PIN]"))
    }

    @Test
    fun `safety policy halts messaging operation with REQUEST_CONFIRMATION`() {
        val engine = com.example.ai.LiteRtLmEngine()
        val apps = listOf(
            com.example.ai.InstalledApp("WhatsApp", "com.whatsapp")
        )

        kotlinx.coroutines.runBlocking {
            val plan = engine.generateAutonomousPlan(
                "Open WhatsApp and send message Rahul hey are we meeting today",
                apps,
                null
            )
            assertEquals("com.whatsapp", plan.targetApp.packageName)
            assertTrue(plan.steps.any { it.actionType == com.example.model.AgentActionType.REQUEST_CONFIRMATION })
            val confirmStep = plan.steps.first { it.actionType == com.example.model.AgentActionType.REQUEST_CONFIRMATION }
            assertEquals("send_message", confirmStep.parameters["action"])
            assertEquals("true", confirmStep.parameters["is_sensitive"])
        }
    }

    @Test
    fun `episodic memory caching accelerates repeated intent patterns`() {
        val engine = com.example.ai.LiteRtLmEngine()
        val apps = listOf(
            com.example.ai.InstalledApp("Chrome", "com.android.chrome")
        )

        val pastExperience = com.example.data.local.TaskExperienceEntity(
            id = "exp-1234",
            intentPattern = "chrome:search_and_open_first_site",
            canonicalPrompt = "open chrome and search wwe superstar and open first site",
            targetPackage = "com.android.chrome",
            executionCount = 5,
            lastSuccessTimestamp = System.currentTimeMillis(),
            averageDurationMs = 850L,
            learnedBypassRules = "pre-dismiss:account_modal",
            learnedSelectors = "[]",
            fastPathStepsCount = 3
        )

        kotlinx.coroutines.runBlocking {
            val plan = engine.generateAutonomousPlan(
                "open chrome and search wwe superstar and open first site",
                apps,
                null,
                pastExperience
            )
            assertTrue(plan.isEpisodicMemoryReused)
            assertEquals("exp-1234", plan.learnedExperienceId)
            assertEquals(6, plan.executionRepetitionCount)
        }
    }

    @Test
    fun `camera capture generates capture_photo action on shutter button`() {
        val engine = com.example.ai.LiteRtLmEngine()
        val apps = listOf(
            com.example.ai.InstalledApp("Camera", "com.android.camera")
        )

        kotlinx.coroutines.runBlocking {
            val plan = engine.generateAutonomousPlan(
                "Open camera and take a photo",
                apps,
                null
            )
            assertEquals("com.android.camera", plan.targetApp.packageName)
            val shutterStep = plan.steps.firstOrNull { it.actionType == com.example.model.AgentActionType.CLICK_ELEMENT }
            assertNotNull(shutterStep)
            assertEquals("capture_photo", shutterStep?.parameters?.get("action"))
            assertEquals("shutter", shutterStep?.parameters?.get("target"))
        }
    }

    @Test
    fun `arbitrary new app like rocker_workout resolves and targets add plan`() {
        val engine = com.example.ai.LiteRtLmEngine()
        val apps = listOf(
            com.example.ai.InstalledApp("Rocker Workout", "com.example.rocker_workout"),
            com.example.ai.InstalledApp("YouTube", "com.google.android.youtube")
        )

        kotlinx.coroutines.runBlocking {
            val plan = engine.generateAutonomousPlan(
                "there is rocker_workout app add a plan",
                apps,
                null
            )
            assertEquals("com.example.rocker_workout", plan.targetApp.packageName)
            assertTrue(plan.steps.any { it.actionType == com.example.model.AgentActionType.LAUNCH_APPLICATION })
            assertTrue(plan.steps.any { it.actionType == com.example.model.AgentActionType.INSPECT_SCREEN })
            val clickStep = plan.steps.firstOrNull { it.actionType == com.example.model.AgentActionType.CLICK_ELEMENT }
            assertNotNull(clickStep)
            assertTrue(clickStep?.target?.contains("plan", ignoreCase = true) == true || clickStep?.target?.contains("add", ignoreCase = true) == true)
        }
    }
}
